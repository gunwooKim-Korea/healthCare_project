package api;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import project.dao.DietDAO;
import project.dao.DietDAOImpl;
import project.dto.DietDTO;
import project.dto.DietListDTO;





public class dietSeCodePullParserTest {
	public static void main(String[] args) {

		
		ArrayList<DietListDTO> totaldata = new ArrayList<DietListDTO>();
		ArrayList<DietDTO> dietTotal = new ArrayList<DietDTO>();

		try {
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			XmlPullParser parser = factory.newPullParser();
			String dieturl = "http://api.nongsaro.go.kr/service/recomendDiet/recomendDietList";
			String key = "20170524HMWY4GQ58W9K4N7SJ1P0HA";
			String seCodeKey = "254002";

			for (int page = 1; page <= 10; page++) {
				
				String urldata = dieturl + "?apiKey=" + key + "&dietSeCode="
						+ seCodeKey + "&pageNo="+page;
				URL url = new URL(urldata);
				BufferedInputStream bis = new BufferedInputStream(
						url.openStream());

				parser.setInput(bis, "utf-8");

				int eventType = parser.getEventType();
				String tag = "";
				String dietlist_Id = "";
				String dietlist_List = "";

				while (eventType != XmlPullParser.END_DOCUMENT) {
					if (eventType == XmlPullParser.START_TAG) {
						tag = parser.getName();
					} else if (eventType == XmlPullParser.TEXT) {
						if (tag.equals("cntntsNo")
								& !parser.getText().contains("\n")) {
							dietlist_Id = parser.getText();
						} else if (tag.equals("dietNm")
								& !parser.getText().contains("\n")) {
							dietlist_List = parser.getText();
						}
					} else if (eventType == XmlPullParser.END_TAG) {
						tag = parser.getName();
						if (tag.equals("item")) {
							DietListDTO data = new DietListDTO(dietlist_Id,
									dietlist_List);
							totaldata.add(data);
						}
					}
					// ���� �̺�Ʈ�� �ѱ��
					eventType = parser.next();
				}
			}
			DiteListDAO service = new DiteListDAOImpl();
			for (int i = 0; i < totaldata.size(); i++) {
				service.insert(totaldata.get(i));
				try {

					Thread.sleep(70);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			dieturl = "http://api.nongsaro.go.kr/service/recomendDiet/recomendDietDtl";
			for (int i = 0; i < totaldata.size(); i++) {
				
				String urldata = dieturl + "?apiKey=" + key + "&cntntsNo="
						+ totaldata.get(i).getdietlist_Id();
				URL url = new URL(urldata);
				BufferedInputStream bis = new BufferedInputStream(
						url.openStream());
				
				parser.setInput(bis, "utf-8");

				int eventType = parser.getEventType();
				
				String tag = "";
				String diet_id = "";
				String diet_name = "";
				String diet_recipe = "";
				String diet_kcal ="";
				String diet_listId = "";
				 
				while (eventType != XmlPullParser.END_DOCUMENT) {
					if (eventType == XmlPullParser.START_TAG) {
						tag = parser.getName();
					} else if (eventType == XmlPullParser.TEXT) {
						if (tag.equals("cntntsNo")
								& !parser.getText().contains("\n")) {
							diet_listId = parser.getText();
						} else if (tag.equals("fdCntntsNo")
								& !parser.getText().contains("\n")) {
							diet_id = parser.getText();
						} else if (tag.equals("fdNm")
								& !parser.getText().contains("\n")) {
							diet_name = parser.getText();
						}else if (tag.equals("ckngMthInfo")) {
							diet_recipe = parser.getText();
						}else if (tag.equals("dietNtrsmallInfo")
								& !parser.getText().contains("\n")) {
							diet_kcal = parser.getText();
						} 
					} else if (eventType == XmlPullParser.END_TAG) {
						tag = parser.getName();
						if(tag.equals("item")) {
							DietDTO data = new DietDTO(diet_id,
									diet_name,
									diet_recipe,
									diet_kcal,
									diet_listId);
							dietTotal.add(data);
						}
					}
					// ���� �̺�Ʈ�� �ѱ��
					eventType = parser.next();
				}
				System.out.println(url);
			}
			
			System.out.println("*******************************");

			DietDAO dietservice = new DietDAOImpl();
			for (int i = 0; i < dietTotal.size(); i++) {
				dietservice.insert(dietTotal.get(i));
				try {
					Thread.sleep(70);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			print(totaldata);
			System.out.println();
			
			print2(dietTotal);
			System.out.println();
			System.out.println("\n*******************************");
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void print(ArrayList<DietListDTO> totaldata) {
		for (int i = 0; i < totaldata.size(); i++) {
			DietListDTO pharmacy = totaldata.get(i);
			System.out.print("dietlist_Id : " + pharmacy.getdietlist_Id()
					+ "\t\tdite_name : " + pharmacy.getdietlist_List() + "\n");
		}
	}
	
	public static void print2(ArrayList<DietDTO> dietTotal) {
		for (int i = 0; i < dietTotal.size(); i++) {
			DietDTO pharmacy = dietTotal.get(i);
			System.out.print(i + " : diet_Id : " + pharmacy.getDiet_id()
					+ "\t\tdiet_name : " + pharmacy.getDiet_name()+ "\t\tdiet_recipe : " + pharmacy.getDiet_recipe() +
					"\t\tdiet_kcal : " +pharmacy.getDiet_kcal()+"\n");
		}
	}
}