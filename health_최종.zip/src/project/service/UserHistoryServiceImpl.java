package project.service;

import project.dao.UserHistoryDAO;
import project.dao.UserHistoryDAOImpl;
import project.dto.UserHistoryDTO;


public class UserHistoryServiceImpl implements UserHistoryService {

	@Override
	public int userhistoryinsert(UserHistoryDTO menuinfo) {
		UserHistoryDAO dao = new UserHistoryDAOImpl();
		int result = dao.addDietMenu(menuinfo);
		return result;
	}
}
