package project.service;

import java.util.Vector;

import project.dto.DietListDTO;

public interface DietListService {

	public Vector<String> getDietList();
	
	DietListDTO recomendDietList(String id);
}
