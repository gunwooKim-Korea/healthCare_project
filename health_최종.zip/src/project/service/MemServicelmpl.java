package project.service;

import java.util.Vector;

import project.dao.DietDAOImpl;
import project.dao.DietListDAO;
import project.dao.DietListDAOImpl;
import project.dao.ExerciseDAO;
import project.dao.ExerciseDAOImpl;
import project.dao.GoalDAO;
import project.dao.GoalDAOimpl;
import project.dao.InbodyInfoDAOImpl;
import project.dao.InbodyinfoDAO;
import project.dao.MemberDAO;
import project.dao.MemberDAOlmpl;
import project.dto.DietDTO;
import project.dto.ExerciseDTO;
import project.dto.GoalDTO;
import project.dto.InbodyinfoDTO;
import project.dto.MemberDTO;

public class MemServicelmpl implements MemService {
	//dao�� insert�� ȣ���ϴ� �޼ҵ�
	
	@Override
	public int mem_signUp(MemberDTO deptinfo) {
		MemberDAOlmpl dao = new MemberDAOlmpl();
		int result = dao.mem_signUp(deptinfo);
		return result;
	}

	@Override
	public int exerinsert(ExerciseDTO deptinfo2) {
		ExerciseDAOImpl dao = new ExerciseDAOImpl();
		int result = dao.exerInsert(deptinfo2);
		return result;
		
	}
	
	// Diet ������� 
	public int adminmenuinsert(DietDTO deptinfo3) {
		DietDAOImpl dao = new DietDAOImpl();
		int result = dao.adminmenuInsert(deptinfo3);
		return result;
	}



	@Override
	public MemberDTO mem_Login(String id, String pass) {
		MemberDAO dao = new MemberDAOlmpl();
		MemberDTO idpassInfo = dao.memLogin(id,pass);
		System.out.println("service���� daoȣ����=>"+idpassInfo);
		return idpassInfo;		
	}

	@Override
	public MemberDTO mem_searchID(String name, String tel, String email) {
		MemberDAO dao = new MemberDAOlmpl();
		MemberDTO nametelemailInfo = dao.memFindID(name, tel, email);
		System.out.println("service���� daoȣ����=>"+nametelemailInfo);
		return nametelemailInfo;
	}

	@Override
	public MemberDTO mem_FindPasswd(String name, String id, String tel,
			String email) {
		MemberDAO dao = new MemberDAOlmpl();
		MemberDTO nameidtelemailinfo = dao.memFindPasswd(name, id, tel, email);
		System.out.println("service���� daoȣ����=>"+nameidtelemailinfo);
		return nameidtelemailinfo;
	}

	@Override
	public MemberDTO mem_updatePasswd(String pass, String id) {
		MemberDAO dao =new MemberDAOlmpl();
		MemberDTO passchangeinfo = dao.memUpdatePasswd(pass, id);
		System.out.println("service���� daoȣ����"+passchangeinfo);
		return passchangeinfo;
	}

	@Override
	public int insertInbodyInfo(InbodyinfoDTO inbodyinfo) {
		InbodyinfoDAO dao =new InbodyInfoDAOImpl();
		
		int result  = dao.insertInbodyInfo(inbodyinfo);
		System.out.println("service���� daoȣ����"+inbodyinfo);
		return result;
		
	}

	@Override
	public InbodyinfoDTO getinbodyinfo(String id) {
		InbodyinfoDAO dao = new InbodyInfoDAOImpl();
		InbodyinfoDTO inbodyinfo = dao.getinbodyinfo(id);
		System.out.println("service���� daoȣ����=>"+inbodyinfo);
		return inbodyinfo;
	}
	
	
	public int goalinsert(GoalDTO goalinfo) {
		GoalDAO dao = new GoalDAOimpl();
		int result = dao.Goalinsert(goalinfo);
		return result;
	}
	
	@Override  // ���� ��ǥ��¼���
	public GoalDTO getGoalselect(String id) {
		GoalDAO dao = new GoalDAOimpl();
		GoalDTO goalselect = dao.getGoalselect(id);
		System.out.println("service���� daoȣ����=>" + goalselect);
		return goalselect;
	}




	@Override
	public Vector<ExerciseDTO> getexerciseinfo() {
			ExerciseDAO dao = new ExerciseDAOImpl();
			Vector<ExerciseDTO> exerciselist = dao.getexerciseinfo();
			return exerciselist;
		
		

   }
}







