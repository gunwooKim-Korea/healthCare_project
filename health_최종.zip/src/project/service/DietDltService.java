package project.service;

import java.util.Vector;

import project.dto.DietDTO;
import project.dto.DietListDTO;

public interface DietDltService {

	public Vector<DietDTO> getDietDTO(DietListDTO dietlist);

	public DietDTO getDietDltInfo(String name);
}
