package project.service;

import java.util.Vector;

import project.dao.DietListDAO;
import project.dao.DietListDAOImpl;
import project.dto.DietListDTO;

public class DietListServiceImpl implements DietListService {

	@Override
	public Vector<String> getDietList() {
		DietListDAO dao = new DietListDAOImpl();
		Vector<String> dietList = dao.getDietListId();
		return dietList;
	}

	@Override
	public DietListDTO recomendDietList(String id) {
		DietListDAO dao = new DietListDAOImpl();
		DietListDTO dietlist = dao.recomendDietList(id);
		System.out.println("service���� daoȣ����"+dietlist);
		return dietlist;
	}
}
