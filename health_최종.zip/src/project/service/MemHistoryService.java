package project.service;

import java.util.Vector;

import project.dto.MemberDTO;
import project.dto.UserHistoryDTO;

public interface MemHistoryService {

	public Vector<String> getDateHistory(MemberDTO memId);
	
	public UserHistoryDTO getHistory(String date, MemberDTO cur_user);
	
	public UserHistoryDTO getUserHistory(String memId,String historydate);
}
