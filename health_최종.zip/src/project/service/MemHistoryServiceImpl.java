package project.service;

import java.util.Vector;

import project.dao.UserHistoryDAO;
import project.dao.UserHistoryDAOImpl;
import project.dto.MemberDTO;
import project.dto.UserHistoryDTO;

public class MemHistoryServiceImpl implements MemHistoryService {

	@Override
	public Vector<String> getDateHistory(MemberDTO memId) {
		UserHistoryDAO dao = new UserHistoryDAOImpl();
		Vector<String> datelist = dao.getDateHistory(memId);
		return datelist;
	}

	@Override
	public UserHistoryDTO getHistory(String date, MemberDTO cur_user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserHistoryDTO getUserHistory(String memId, String historydate) {
		UserHistoryDAO dao = new UserHistoryDAOImpl();
		UserHistoryDTO historyList = dao.getUserHistory(memId, historydate);
		System.out.println("sevice :"+historyList);
		return historyList;
	}

}
