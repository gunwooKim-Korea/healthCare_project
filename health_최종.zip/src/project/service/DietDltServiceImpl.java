package project.service;

import static project.fw.DBUtil.*;
import static project.fw.QueryDietDlt.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import project.dto.DietDTO;
import project.dto.DietListDTO;
import project.view.SelectGoalPage;

public class DietDltServiceImpl implements DietDltService {

	@Override
	public Vector<DietDTO> getDietDTO(DietListDTO dietList) {
		Vector<DietDTO> dietDltList = new Vector<DietDTO>();

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			con = getConnect();
			stmt = con.prepareStatement(SELECT_DietDltList);
			stmt.setString(1, dietList.getdietlist_Id());
			rs = stmt.executeQuery();

			while (rs.next()) {
				DietDTO dietDlt = new DietDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5));

				dietDltList.add(dietDlt);
			}
			System.out.println("������ȸ?" + dietList);
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}

		return dietDltList;
	}

	@Override
	public DietDTO getDietDltInfo(String name) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		DietDTO dietDlt = null;

		try {
			con = getConnect();
			stmt = con.prepareStatement(SELECT_DietDltInfo);
//			stmt.setString(1, dietListId.getDiet_listId());
			stmt.setString(1,  name);
			rs = stmt.executeQuery();
			
			while (rs.next()) {
				dietDlt = new DietDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5));
			}
			
			System.out.println("������ȸ?" + dietDlt.toString());
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return dietDlt;
	}

}
