package project.dto;

import java.util.Date;

public class MemhistoryDTO {
	Date historydate;
	String dietBreakfast_id;
	String dietBreakfast_op;
	String dietLaunch;
	String dietDinner_id;
	String dietDinner_op;
	String ex_id;
	String mem_id;
	
	
	public MemhistoryDTO(){}


	public MemhistoryDTO(Date historydate, String dietBreakfast_id,
			String dietBreakfast_op, String dietLaunch, String dietDinner_id,
			String dietDinner_op, String ex_id, String mem_id) {
		this.historydate = historydate;
		this.dietBreakfast_id = dietBreakfast_id;
		this.dietBreakfast_op = dietBreakfast_op;
		this.dietLaunch = dietLaunch;
		this.dietDinner_id = dietDinner_id;
		this.dietDinner_op = dietDinner_op;
		this.ex_id = ex_id;
		this.mem_id = mem_id;
	}


	public Date getHistorydate() {
		return historydate;
	}


	public void setHistorydate(Date historydate) {
		this.historydate = historydate;
	}


	public String getDietBreakfast_id() {
		return dietBreakfast_id;
	}


	public void setDietBreakfast_id(String dietBreakfast_id) {
		this.dietBreakfast_id = dietBreakfast_id;
	}


	public String getDietBreakfast_op() {
		return dietBreakfast_op;
	}


	public void setDietBreakfast_op(String dietBreakfast_op) {
		this.dietBreakfast_op = dietBreakfast_op;
	}


	public String getDietLaunch() {
		return dietLaunch;
	}


	public void setDietLaunch(String dietLaunch) {
		this.dietLaunch = dietLaunch;
	}


	public String getDietDinner_id() {
		return dietDinner_id;
	}


	public void setDietDinner_id(String dietDinner_id) {
		this.dietDinner_id = dietDinner_id;
	}


	public String getDietDinner_op() {
		return dietDinner_op;
	}


	public void setDietDinner_op(String dietDinner_op) {
		this.dietDinner_op = dietDinner_op;
	}


	public String getEx_id() {
		return ex_id;
	}


	public void setEx_id(String ex_id) {
		this.ex_id = ex_id;
	}


	public String getMem_id() {
		return mem_id;
	}


	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}


	@Override
	public String toString() {
		return "MemhistoryDTO [historydate=" + historydate
				+ ", dietBreakfast_id=" + dietBreakfast_id
				+ ", dietBreakfast_op=" + dietBreakfast_op + ", dietLaunch="
				+ dietLaunch + ", dietDinner_id=" + dietDinner_id
				+ ", dietDinner_op=" + dietDinner_op + ", ex_id=" + ex_id
				+ ", mem_id=" + mem_id + "]";
	}
	
	
	
	
}
