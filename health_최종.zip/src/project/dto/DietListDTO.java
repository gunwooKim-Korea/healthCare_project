package project.dto;

public class DietListDTO {
	String dietlist_Id;
	String dietlist_List;
	
	public DietListDTO(){}
	
	
	public DietListDTO(String dietlist_Id) {
		super();
		this.dietlist_Id = dietlist_Id;
	}

	public DietListDTO(String dietlist_Id, String dietlist_List) {
		super();
		this.dietlist_Id = dietlist_Id;
		this.dietlist_List = dietlist_List;
	}


	public String getdietlist_Id() {
		return dietlist_Id;
	}

	public void setdietlist_Id(String dietlist_Id) {
		this.dietlist_Id = dietlist_Id;
	}

	public String getdietlist_List() {
		return dietlist_List;
	}

	public void setdietlist_List(String dietlist_List) {
		this.dietlist_List = dietlist_List;
	}


	@Override
	public String toString() {
		return "DietDTO [dietlist_Id=" + dietlist_Id + ", dietlist_List=" + dietlist_List+"]";
	}
	
	
	
}
