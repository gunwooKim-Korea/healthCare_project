package project.dto;

public class MemberDTO {
	String mem_id;
	String mem_name;
	String mem_passwd;
	String mem_gender;
	String mem_tel;
	String mem_email;
	String mem_systdate;
	public MemberDTO(String mem_id, String mem_name, String mem_passwd,
			String mem_gender, String mem_tel, String mem_email,
			String mem_systdate) {
		super();
		this.mem_id = mem_id;
		this.mem_name = mem_name;
		this.mem_passwd = mem_passwd;
		this.mem_gender = mem_gender;
		this.mem_tel = mem_tel;
		this.mem_email = mem_email;
		this.mem_systdate = mem_systdate;
	}
	
	
	public MemberDTO(String mem_id, String mem_name, String mem_passwd,
			String mem_gender, String mem_tel, String mem_email) {
		super();
		this.mem_id = mem_id;
		this.mem_name = mem_name;
		this.mem_passwd = mem_passwd;
		this.mem_gender = mem_gender;
		this.mem_tel = mem_tel;
		this.mem_email = mem_email;
	}


	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMem_name() {
		return mem_name;
	}
	public void setMem_name(String mem_name) {
		this.mem_name = mem_name;
	}
	public String getMem_passwd() {
		return mem_passwd;
	}
	public void setMem_passwd(String mem_passwd) {
		this.mem_passwd = mem_passwd;
	}
	public String getMem_gender() {
		return mem_gender;
	}
	public void setMem_gender(String mem_gender) {
		this.mem_gender = mem_gender;
	}
	public String getMem_tel() {
		return mem_tel;
	}
	public void setMem_tel(String mem_tel) {
		this.mem_tel = mem_tel;
	}
	public String getMem_email() {
		return mem_email;
	}
	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}
	public String getMem_systdate() {
		return mem_systdate;
	}
	public void setMem_systdate(String mem_systdate) {
		this.mem_systdate = mem_systdate;
	}
	
	
	@Override
	public String toString() {
		return "MemberDTO [mem_id=" + mem_id + ", mem_name=" + mem_name
				+ ", mem_passwd=" + mem_passwd + ", mem_gender=" + mem_gender
				+ ", mem_tel=" + mem_tel + ", mem_email=" + mem_email
				+ ", mem_systdate=" + mem_systdate + "]";
	}
	
	
}
