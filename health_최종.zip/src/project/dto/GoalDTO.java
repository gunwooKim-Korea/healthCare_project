package project.dto;

import java.sql.Date;
//sql Date�� import�ؾ��Ѵ�.


public class GoalDTO {
	
	String mem_id;
	String goal_finaldate;
	String goal_weight;
	String goal_muscle;
	
	public GoalDTO(){}


	public GoalDTO(String mem_id, String goal_finaldate, String goal_weight,
			String goal_muscle) {
		super();
		this.mem_id = mem_id;
		this.goal_finaldate = goal_finaldate;
		this.goal_weight = goal_weight;
		this.goal_muscle = goal_muscle;
	}
	
	


	public String getMem_id() {
		return mem_id;
	}


	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}


	public String getGoal_finaldate() {
		return goal_finaldate;
	}


	public void setGoal_finaldate(String goal_finaldate) {
		this.goal_finaldate = goal_finaldate;
	}


	public String getGoal_weight() {
		return goal_weight;
	}


	public void setGoal_weight(String goal_weight) {
		this.goal_weight = goal_weight;
	}


	public String getGoal_muscle() {
		return goal_muscle;
	}


	public void setGoal_muscle(String goal_muscle) {
		this.goal_muscle = goal_muscle;
	}


	@Override
	public String toString() {
		return "GoalDTO [mem_id=" + mem_id + ", goal_finaldate="
				+ goal_finaldate + ", goal_weight=" + goal_weight
				+ ", goal_muscle=" + goal_muscle + "]";
	}

		
	
	
		
	
	
	
	
	
	
	
  
}
