package project.dto;

public class ManagerMenuDTO {
String menuname;
String totalcal;
String link;
public ManagerMenuDTO() {}
public ManagerMenuDTO(String menuname, String totalcal, String link) {
	super();
	this.menuname = menuname;
	this.totalcal = totalcal;
	this.link = link;
}
public String getMenuname() {
	return menuname;
}
public void setMenuname(String menuname) {
	this.menuname = menuname;
}
public String getTotalcal() {
	return totalcal;
}
public void setTotalcal(String totalcal) {
	this.totalcal = totalcal;
}
public String getLink() {
	return link;
}
public void setLink(String link) {
	this.link = link;
}
@Override
public String toString() {
	return "ManagerMenuDTO [menuname=" + menuname + ", totalcal=" + totalcal
			+ ", link=" + link + "]";
}

}
