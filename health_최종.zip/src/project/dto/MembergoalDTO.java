package project.dto;

import java.util.Date;

public class MembergoalDTO {
	String mem_id;
	Date memgol_finaldate;
	float memgol_weight;
	float memgol_muscle;
	
	
	public MembergoalDTO(){}


	public MembergoalDTO(String mem_id, Date memgol_finaldate,
			float memgol_weight, float memgol_muscle) {
		this.mem_id = mem_id;
		this.memgol_finaldate = memgol_finaldate;
		this.memgol_weight = memgol_weight;
		this.memgol_muscle = memgol_muscle;
	}


	public String getMem_id() {
		return mem_id;
	}


	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}


	public Date getMemgol_finaldate() {
		return memgol_finaldate;
	}


	public void setMemgol_finaldate(Date memgol_finaldate) {
		this.memgol_finaldate = memgol_finaldate;
	}


	public float getMemgol_weight() {
		return memgol_weight;
	}


	public void setMemgol_weight(float memgol_weight) {
		this.memgol_weight = memgol_weight;
	}


	public float getMemgol_muscle() {
		return memgol_muscle;
	}


	public void setMemgol_muscle(float memgol_muscle) {
		this.memgol_muscle = memgol_muscle;
	}


	@Override
	public String toString() {
		return "MembergoalDTO [mem_id=" + mem_id + ", memgol_finaldate="
				+ memgol_finaldate + ", memgol_weight=" + memgol_weight
				+ ", memgol_muscle=" + memgol_muscle + "]";
	}
	
	

}
