package project.dto;

public class DietDTO {
	String diet_id;
	String diet_name;
	String diet_recipe;
	String diet_kcal;
	String diet_listId;
	
	public DietDTO(String diet_id, String diet_name, String diet_recipe,
			String diet_kcal, String diet_listId) {
		super();
		this.diet_id = diet_id;
		this.diet_name = diet_name;
		this.diet_recipe = diet_recipe;
		this.diet_kcal = diet_kcal;
		this.diet_listId = diet_listId;
	}
	public String getDiet_id() {
		return diet_id;
	}
	public void setDiet_id(String diet_id) {
		this.diet_id = diet_id;
	}
	public String getDiet_name() {
		return diet_name;
	}
	public void setDiet_name(String diet_name) {
		this.diet_name = diet_name;
	}
	public String getDiet_recipe() {
		return diet_recipe;
	}
	public void setDiet_recipe(String diet_recipe) {
		this.diet_recipe = diet_recipe;
	}
	public String getDiet_kcal() {
		return diet_kcal;
	}
	public void setDiet_kcal(String diet_kcal) {
		this.diet_kcal = diet_kcal;
	}
	public String getDiet_listId() {
		return diet_listId;
	}
	public void setDiet_listId(String diet_listId) {
		this.diet_listId = diet_listId;
	}
	@Override
	public String toString() {
		return "DietDTO [diet_id=" + diet_id + ", diet_name=" + diet_name
				+ ", diet_recipe=" + diet_recipe + ", diet_kcal=" + diet_kcal
				+ ", diet_listId=" + diet_listId + "]";
	}
	
	
}
