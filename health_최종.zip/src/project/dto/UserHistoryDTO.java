package project.dto;

import java.util.Date;

public class UserHistoryDTO {
	String memId;
	String historydate;
	String dietBreakfast_name;
	String dietDinner_name;
	String kcal;

	
	public UserHistoryDTO() {
		super();
	}

	public UserHistoryDTO(String historydate,String memId, 
			String dietBreakfast_name, String dietDinner_name, String kcal) {
		super();
		this.memId = memId;
		this.historydate = historydate;
		this.dietBreakfast_name = dietBreakfast_name;
		this.dietDinner_name = dietDinner_name;
		this.kcal = kcal;
	}


	public String getMemId() {
		return memId;
	}


	public void setMemId(String memId) {
		this.memId = memId;
	}


	public String getHistorydate() {
		return historydate;
	}


	public void setHistorydate(String historydate) {
		this.historydate = historydate;
	}


	public String getDietBreakfast_name() {
		return dietBreakfast_name;
	}


	public void setDietBreakfast_name(String dietBreakfast_name) {
		this.dietBreakfast_name = dietBreakfast_name;
	}


	public String getDietDinner_name() {
		return dietDinner_name;
	}


	public void setDietDinner_name(String dietDinner_name) {
		this.dietDinner_name = dietDinner_name;
	}


	public String getKcal() {
		return kcal;
	}


	public void setKcal(String kcal) {
		this.kcal = kcal;
	}


	@Override
	public String toString() {
		return "MemhistoryDTO [memId=" + memId + ", historydate=" + historydate
				+ ", dietBreakfast_name=" + dietBreakfast_name
				+ ", dietDinner_name=" + dietDinner_name + ", kcal=" + kcal
				+ "]";
	}

	
	


	
}
