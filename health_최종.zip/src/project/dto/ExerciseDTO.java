package project.dto;

import javax.swing.JLabel;

public class ExerciseDTO {
	String ex_id;
	String ex_name;
	String ex_kcal;
	String ex_videolink;
	String ex_type;

	public ExerciseDTO(String ex_id, String ex_name, String ex_kcal,
			String ex_videolink, String ex_type) {
		super();
		this.ex_id = ex_id;
		this.ex_name = ex_name;
		this.ex_kcal = ex_kcal;
		this.ex_videolink = ex_videolink;
		this.ex_type = ex_type;
	}

	public String getEx_id() {
		return ex_id;
	}

	public void setEx_id(String ex_id) {
		this.ex_id = ex_id;
	}

	public String getEx_name() {
		return ex_name;
	}

	public void setEx_name(String ex_name) {
		this.ex_name = ex_name;
	}

	public String getEx_kcal() {
		return ex_kcal;
	}

	public void setEx_kcal(String ex_kcal) {
		this.ex_kcal = ex_kcal;
	}

	public String getEx_videolink() {
		return ex_videolink;
	}

	public void setEx_videolink(String ex_videolink) {
		this.ex_videolink = ex_videolink;
	}

	public String getEx_type() {
		return ex_type;
	}

	public void setEx_type(String ex_type) {
		this.ex_type = ex_type;
	}
}
