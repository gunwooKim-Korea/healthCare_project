package project.dto;

import javax.swing.JLabel;

public class ManagerExerDTO {
String exerciseid;
String exercisename;
String kcal;
String videolink;
String kindtype;
public ManagerExerDTO(){}
public ManagerExerDTO(String exerciseid, String exercisename, String kcal,
		String videolink, String kindtype) {
	super();
	this.exerciseid = exerciseid;
	this.exercisename = exercisename;
	this.kcal = kcal;
	this.videolink = videolink;
	this.kindtype = kindtype;
}
public String getExerciseid() {
	return exerciseid;
}
public void setExerciseid(String exerciseid) {
	this.exerciseid = exerciseid;
}
public String getExercisename() {
	return exercisename;
}
public void setExercisename(String exercisename) {
	this.exercisename = exercisename;
}
public String getKcal() {
	return kcal;
}
public void setKcal(String kcal) {
	this.kcal = kcal;
}
public String getVideolink() {
	return videolink;
}
public void setVideolink(String videolink) {
	this.videolink = videolink;
}
public String getKindtype() {
	return kindtype;
}
public void setKindtype(String kindtype) {
	this.kindtype = kindtype;
}
@Override
public String toString() {
	return "ManagerExerDTO [exerciseid=" + exerciseid + ", exercisename="
			+ exercisename + ", kcal=" + kcal + ", videolink=" + videolink
			+ ", kindtype=" + kindtype + "]";
}

}








