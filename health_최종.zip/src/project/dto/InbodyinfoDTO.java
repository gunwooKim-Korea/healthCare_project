package project.dto;

import java.util.Date;

public class InbodyinfoDTO {
	Date inbdy_date;
	String inbdy_height;
	String inbdy_weight;
	String inbdy_metabolism;
	String inbdy_musclemass;
	String inbdy_inbdybodyfat;
	String mem_id;
	
	public InbodyinfoDTO(String inbdy_height, String inbdy_weight,
			String inbdy_metabolism, String inbdy_musclemass,
			String inbdy_inbdybodyfat, String mem_id) {
		super();
		this.inbdy_height = inbdy_height;
		this.inbdy_weight = inbdy_weight;
		this.inbdy_metabolism = inbdy_metabolism;
		this.inbdy_musclemass = inbdy_musclemass;
		this.inbdy_inbdybodyfat = inbdy_inbdybodyfat;
		this.mem_id = mem_id;
	}
	public InbodyinfoDTO(Date inbdy_date, String inbdy_height,
			String inbdy_weight, String inbdy_metabolism,
			String inbdy_musclemass, String inbdy_inbdybodyfat, String mem_id) {
		super();
		this.inbdy_date = inbdy_date;
		this.inbdy_height = inbdy_height;
		this.inbdy_weight = inbdy_weight;
		this.inbdy_metabolism = inbdy_metabolism;
		this.inbdy_musclemass = inbdy_musclemass;
		this.inbdy_inbdybodyfat = inbdy_inbdybodyfat;
		this.mem_id = mem_id;
	}
	public Date getInbdy_date() {
		return inbdy_date;
	}
	public void setInbdy_date(Date inbdy_date) {
		this.inbdy_date = inbdy_date;
	}
	public String getInbdy_height() {
		return inbdy_height;
	}
	public void setInbdy_height(String inbdy_height) {
		this.inbdy_height = inbdy_height;
	}
	public String getInbdy_weight() {
		return inbdy_weight;
	}
	public void setInbdy_weight(String inbdy_weight) {
		this.inbdy_weight = inbdy_weight;
	}
	public String getInbdy_metabolism() {
		return inbdy_metabolism;
	}
	public void setInbdy_metabolism(String inbdy_metabolism) {
		this.inbdy_metabolism = inbdy_metabolism;
	}
	public String getInbdy_musclemass() {
		return inbdy_musclemass;
	}
	public void setInbdy_musclemass(String inbdy_musclemass) {
		this.inbdy_musclemass = inbdy_musclemass;
	}
	public String getInbdy_inbdybodyfat() {
		return inbdy_inbdybodyfat;
	}
	public void setInbdy_inbdybodyfat(String inbdy_inbdybodyfat) {
		this.inbdy_inbdybodyfat = inbdy_inbdybodyfat;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	@Override
	public String toString() {
		return "InbodyinfoDTO [inbdy_date=" + inbdy_date + ", inbdy_height="
				+ inbdy_height + ", inbdy_weight=" + inbdy_weight
				+ ", inbdy_metabolism=" + inbdy_metabolism
				+ ", inbdy_musclemass=" + inbdy_musclemass
				+ ", inbdy_inbdybodyfat=" + inbdy_inbdybodyfat + ", mem_id="
				+ mem_id + "]";
	}
	
}
