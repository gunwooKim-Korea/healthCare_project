package project.fw;

public class QueryDietDlt {
	
	public static String SELECT_DietDltList = "select * from diettable where dietlist_id = ?";
	
	public static String SELECT_DietDltInfo = "select * from diettable where diet_name = ?";
	public static String SELECT_DietDltInfo3 = "select * from diettable where DIETLIST_ID= ? and diet_name like '%?%';";

	public static String SELECT_DietDltInfo2 = "select dlt.* from diettable dlt, dietlisttable dlist where dlist.dietlist_name like ? and dlt.dietlist_id = dlist.dietlist_id";
}