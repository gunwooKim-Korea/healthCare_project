package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;

public class PasswdPage extends JPanel {
	public JTextField txt_changepasswd;
	public JTextField txt_curpass;
	public JLabel lbl_curpass;
	public JLabel lbl_changepasswd;
	public JLabel lbl_changeconfirmpasswd;
	public JButton btn_PasswdEnter;
	public JTextField txt_changeconfirmpasswd;

	/**
	 * Create the panel.
	 */
	public PasswdPage() {
		setBackground(Color.ORANGE);
		setLayout(null);
		
		lbl_curpass = new JLabel("\uD604\uC7AC\uBE44\uBC00\uBC88\uD638 :");
		lbl_curpass.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_curpass.setBounds(12, 25, 146, 62);
		add(lbl_curpass);
		
		lbl_changepasswd = new JLabel("\uBCC0\uACBD\uD560 \uBE44\uBC00\uBC88\uD638 : ");
		lbl_changepasswd.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_changepasswd.setToolTipText("\uBCC0\uACBD\uD560 \uBE44\uBC00\uBC88\uD638 \uC7AC\uD655\uC778 :");
		lbl_changepasswd.setBounds(12, 88, 146, 62);
		add(lbl_changepasswd);
		
		lbl_changeconfirmpasswd = new JLabel("\uBCC0\uACBD\uD560 \uBE44\uBC00\uBC88\uD638 \uC7AC\uD655\uC778 :");
		lbl_changeconfirmpasswd.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_changeconfirmpasswd.setBounds(12, 150, 146, 62);
		add(lbl_changeconfirmpasswd);
		
		txt_curpass = new JTextField();
		txt_curpass.setColumns(10);
		txt_curpass.setBounds(166, 25, 272, 53);
		add(txt_curpass);
		
		txt_changepasswd = new JTextField();
		txt_changepasswd.setColumns(10);
		txt_changepasswd.setBounds(166, 88, 272, 53);
		add(txt_changepasswd);
		
		txt_changeconfirmpasswd = new JTextField();
		txt_changeconfirmpasswd.setBounds(166, 155, 272, 53);
		add(txt_changeconfirmpasswd);
		txt_changeconfirmpasswd.setColumns(10);
		
		btn_PasswdEnter = new JButton("\uD655\uC778");
		btn_PasswdEnter.setBounds(320, 239, 97, 51);
		add(btn_PasswdEnter);

	}

}
