package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import java.awt.CardLayout;
import java.awt.Font;
import java.awt.Color;

import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class ExerciseRecommend extends JPanel {
	public JTextArea textArea;
	public JPanel topPanel;
	public JScrollPane scroll;
	

	/**
	 * Create the panel.
	 */
	public ExerciseRecommend() {
		setLayout(null);
		
		topPanel = new JPanel();
		topPanel.setBounds(12, 0, 417, 61);
		add(topPanel);
		topPanel.setLayout(null);
		
		JLabel label = new JLabel("\uC6B4\uB3D9\uBC88\uD638 / \uC6B4\uB3D9\uBA85 / \uC18C\uBAA8\uCE7C\uB85C\uB9AC / \uCD94\uCC9C\uB9C1\uD06C / \uC6B4\uB3D9\uC131\uACA9");
		label.setFont(new Font("����", Font.BOLD, 13));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(12, 5, 393, 46);
		topPanel.add(label);
		
		
		textArea = new JTextArea(10,20);
		textArea.setFont(new Font("�޸տ�����", Font.BOLD, 16));
		textArea.setBackground(Color.ORANGE);
		scroll = new JScrollPane(textArea);
		scroll.setBounds(12, 71, 417, 237);
		add(scroll);
		
		
		
		
		
		
		

	}
}
