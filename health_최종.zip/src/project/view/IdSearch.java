package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;

public class IdSearch extends JPanel {
	public JTextField txt_name;
	public JTextField txt_phoneNumber;
	public JTextField txt_email;
	public JPanel panel;
	public JLabel lbl_idsearch;
	public JLabel lbl_name;
	public JLabel lbl_phoneNumber;
	public JButton btn_IdEnter;

	/**
	 * Create the panel.
	 */
	public IdSearch() {
		setLayout(null);
		
		panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 5, 450, 209);
		add(panel);
		panel.setLayout(null);
		
		lbl_idsearch = new JLabel("ID\uCC3E\uAE30 ");
		lbl_idsearch.setBounds(191, 5, 68, 24);
		lbl_idsearch.setFont(new Font("����", Font.BOLD, 20));
		panel.add(lbl_idsearch);
		
		lbl_name = new JLabel("\uC774\uB984");
		lbl_name.setFont(new Font("����", Font.BOLD, 16));
		lbl_name.setBounds(123, 51, 68, 24);
		panel.add(lbl_name);
		
		lbl_phoneNumber = new JLabel("\uD578\uB4DC\uD3F0\uBC88\uD638");
		lbl_phoneNumber.setFont(new Font("����", Font.BOLD, 16));
		lbl_phoneNumber.setBounds(123, 85, 105, 24);
		panel.add(lbl_phoneNumber);
		
		txt_name = new JTextField();
		txt_name.setBounds(213, 54, 116, 21);
		panel.add(txt_name);
		txt_name.setColumns(10);
		
		txt_phoneNumber = new JTextField();
		txt_phoneNumber.setColumns(10);
		txt_phoneNumber.setBounds(213, 88, 116, 21);
		panel.add(txt_phoneNumber);
		
		btn_IdEnter = new JButton("\uD655\uC778");
		btn_IdEnter.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		btn_IdEnter.setBounds(232, 159, 97, 23);
		panel.add(btn_IdEnter);
		
		JLabel lbl_email = new JLabel("\uC774\uBA54\uC77C");
		lbl_email.setFont(new Font("����", Font.BOLD, 16));
		lbl_email.setBounds(123, 117, 105, 24);
		panel.add(lbl_email);
		
		txt_email = new JTextField();
		txt_email.setColumns(10);
		txt_email.setBounds(213, 119, 116, 21);
		panel.add(txt_email);

	}

}
