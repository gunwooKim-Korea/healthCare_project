package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.JButton;

public class SelectMealMenuPage extends JPanel {
	public JPanel panel;
	public JButton btn_FstMeal;
	public JButton btn_SndMeal;

	/**
	 * Create the panel.
	 */
	public SelectMealMenuPage() {
		setLayout(null);
		
		JPanel cardpanel = new JPanel();
		cardpanel.setBounds(12, 10, 426, 280);
		add(cardpanel);
		cardpanel.setLayout(new CardLayout(0, 0));
		
		panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		cardpanel.add(panel, "MealManuPage");
		panel.setLayout(null);
		
		JLabel label = new JLabel("1)");
		label.setBounds(12, 64, 26, 27);
		panel.add(label);
		label.setFont(new Font("����", Font.BOLD, 18));
		
		JLabel label_1 = new JLabel("2)");
		label_1.setBounds(12, 174, 26, 27);
		panel.add(label_1);
		label_1.setFont(new Font("����", Font.BOLD, 18));
		
		JLabel lblX = new JLabel("\uCD94\uCC9C\uB41C \uC2DD\uB2E8");
		lblX.setBounds(154, 18, 114, 26);
		panel.add(lblX);
		lblX.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		
		btn_FstMeal = new JButton("New button");
		btn_FstMeal.setBounds(50, 54, 353, 50);
		panel.add(btn_FstMeal);
		
		btn_SndMeal = new JButton("New button");
		btn_SndMeal.setBounds(50, 164, 353, 50);
		panel.add(btn_SndMeal);

	}
}
