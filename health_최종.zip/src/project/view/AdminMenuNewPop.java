package project.view;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import project.controller.AdminMenuNewPopListener;

public class AdminMenuNewPop extends JFrame {

	public JPanel contentPane;
	public JTextField txt_dietId;
	public JTextField txt_dietName;
	public JTextField txt_Kcal;
	public JPanel panel;
	public JLabel lbl_dietId;
	public JLabel lbl_dietName;
	public JLabel lblKcal;
	public JLabel lbl_Recipe;
	public  JTextArea ta_RecipeExplain;
	public JScrollBar scrollBar;
	public JButton btn_AdminNewPopEnter;
	public JScrollPane scrollPane;
	public JTextArea ta_Recipe;

	boolean visible;
	public JTextField txt_dietlistId;
	public JLabel lblNewLabel;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					AdminMenuNewPop frame = new AdminMenuNewPop();
//					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminMenuNewPop(boolean visible) {
		setVisible(visible);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(5, 5, 424, 282);
		contentPane.add(panel);
		panel.setLayout(null);
		
		lbl_dietId = new JLabel("\uC2DD\uB2E8ID");
		lbl_dietId.setFont(new Font("����", Font.BOLD, 15));
		lbl_dietId.setBounds(12, 10, 57, 29);
		panel.add(lbl_dietId);
		
		lbl_dietName = new JLabel("\uC74C\uC2DD\uC774\uB984");
		lbl_dietName.setFont(new Font("����", Font.BOLD, 15));
		lbl_dietName.setBounds(12, 44, 68, 21);
		panel.add(lbl_dietName);
		
		lblKcal = new JLabel("Kcal");
		lblKcal.setFont(new Font("����", Font.BOLD, 15));
		lblKcal.setBounds(12, 76, 57, 21);
		panel.add(lblKcal);
		
		lbl_Recipe = new JLabel("\uB808\uC2DC\uD53C \uC124\uBA85");
		lbl_Recipe.setFont(new Font("����", Font.BOLD, 15));
		lbl_Recipe.setBounds(12, 144, 97, 29);
		panel.add(lbl_Recipe);
		
		txt_dietId = new JTextField();
		txt_dietId.setBounds(81, 7, 223, 29);
		panel.add(txt_dietId);
		txt_dietId.setColumns(10);
		
		txt_dietName = new JTextField();
		txt_dietName.setColumns(10);
		txt_dietName.setBounds(81, 42, 223, 29);
		panel.add(txt_dietName);
		
		txt_Kcal = new JTextField();
		txt_Kcal.setColumns(10);
		txt_Kcal.setBounds(81, 77, 223, 29);
		panel.add(txt_Kcal);
		
		ta_Recipe = new JTextArea();
		ta_Recipe.setBounds(14, 13, 400, 102);
		panel.add(ta_Recipe);
		
		JScrollPane scrollPane = new JScrollPane(ta_Recipe);
		scrollPane.setBounds(12, 173, 400, 69);
		panel.add(scrollPane);
		
		btn_AdminNewPopEnter = new JButton("\uD655\uC778");
		btn_AdminNewPopEnter.setBounds(315, 245, 97, 27);
		panel.add(btn_AdminNewPopEnter);
		
		txt_dietlistId = new JTextField();
		txt_dietlistId.setBounds(112, 116, 224, 21);
		panel.add(txt_dietlistId);
		txt_dietlistId.setColumns(10);
		
		lblNewLabel = new JLabel("\uC2DD\uB2E8\uB9AC\uC2A4\uD2B8 ID");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 13));
		lblNewLabel.setBounds(12, 119, 124, 15);
		panel.add(lblNewLabel);
		
		startEvent();
	}

	public void startEvent() {
		AdminMenuNewPopListener poplistner = new AdminMenuNewPopListener(this);
		btn_AdminNewPopEnter.addActionListener(poplistner);
	}
}
