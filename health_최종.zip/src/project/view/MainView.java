package project.view;


import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import project.controller.AdminListener;
import project.controller.DietMenuChangePageListener;
import project.controller.InbodyInfoListener;
import project.controller.InformChangePageListener;
import project.controller.LoginListener;
import project.controller.MainLisener;
import project.controller.MemHistoryListener;
import project.controller.SelectGoalPageListener;
import project.controller.SelectMealMenuListener;
import project.dto.MemberDTO;



public class MainView extends JFrame {

	public static MemberDTO cur_user;
	public static JButton btn_back;
	public static JPanel cardPanel;
	public static CardLayout card;

	public JPanel contentPane;
	public JButton btn_Goal;
	public JButton btn_State;
	public JButton btn_Progress;
	public JButton btn_Menu;
	public JButton btn_Exercise;
	public JButton btn_Logout;
	public JButton btn_Change;
	public JPanel mainView;
	public GoalView goalView;
	public MemHistoryView stateView;
	public ProcView procView;
	public JLabel Mainbackground;
	public JLabel Downarea;
	public ExerciseRecommend exercisePage;
	public InbodyPage inbodyPage;
	public PasswdPage passwdPage;
	public Schedulepage schedulepage;
	public PassSearch passSearch;
	public JoinUs joinUs;
	public IdSearch idSearch;
	public SelectMealMenuPage selectMealMenuPage;
	public SelectMealtime selectMealtime;
	public InformChangePage informChangePage;
	public SelectGoalPage selectGoalPage;
	public LoginPage loginPage;
	public InsertOk insertOk;
	public AdminExercise adminExercise;
	public AdminPage adminView;
	public ExerciseView exerciseView;
	public UserHistoryView userHistoryView;
	public DietMenuChangePage dietMenuChangePage;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainView frame = new MainView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public MainView() {		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 628);
		contentPane = new JPanel();
		contentPane.setBackground(Color.LIGHT_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		cardPanel = new JPanel();
		cardPanel.setBackground(new Color(255, 255, 255));
		cardPanel.setBounds(120, 82, 454, 363);
		contentPane.add(cardPanel);
		card = new CardLayout(0,0);
		cardPanel.setLayout(card);
		
		mainView = new JPanel();
		mainView.setBackground(new Color(255, 250, 205));
		cardPanel.add(mainView, "main");
		mainView.setLayout(null);
		
		btn_Goal = new JButton("\uBAA9\uD45C\uC870\uD68C");
		btn_Goal.setBackground(new Color(153, 204, 102));
		btn_Goal.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		btn_Goal.setBounds(12, 10, 138, 108);
		mainView.add(btn_Goal);
		
		btn_State = new JButton("\uC774\uC6A9\uB0B4\uB825");
		btn_State.setBackground(new Color(153, 204, 102));
		btn_State.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		btn_State.setBounds(162, 10, 138, 108);
		mainView.add(btn_State);
		
		btn_Progress = new JButton("\uC778\uBC14\uB514\uC815\uBCF4");
		btn_Progress.setBackground(new Color(153, 204, 102));
		btn_Progress.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		btn_Progress.setBounds(312, 10, 130, 108);
		mainView.add(btn_Progress);
		
		btn_Menu = new JButton("\uC2DD\uB2E8\uC120\uD0DD");
		btn_Menu.setBackground(new Color(153, 204, 102));
		btn_Menu.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		btn_Menu.setBounds(12, 128, 430, 101);
		mainView.add(btn_Menu);
		
		btn_Exercise = new JButton("\uC6B4\uB3D9\uAD00\uB9AC");
		btn_Exercise.setBackground(new Color(153, 204, 102));
		btn_Exercise.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		btn_Exercise.setBounds(12, 239, 138, 112);
		mainView.add(btn_Exercise);
		
		btn_Logout = new JButton("\uB85C\uADF8\uC544\uC6C3");
		btn_Logout.setBackground(new Color(153, 204, 102));
		btn_Logout.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		btn_Logout.setBounds(162, 239, 138, 112);
		mainView.add(btn_Logout);
		
		btn_Change = new JButton("��������");
		btn_Change.setBackground(new Color(153, 204, 102));
		btn_Change.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		btn_Change.setBounds(312, 239, 130, 112);
		mainView.add(btn_Change);
		card.first(cardPanel);
		
		goalView = new GoalView();
		cardPanel.add(goalView, "Goal");
		
//		stateView = new MemHistoryView();
//		cardPanel.add(stateView, "State");
		
		procView = new ProcView();
		cardPanel.add(procView, "Prog");
		
		Downarea = new JLabel("");
		Downarea.setIcon(new ImageIcon("C:\\Users\\kitri\\Desktop\\\uBC30\uACBD\uC774\uBBF8\uC9C0\uBA54\uC778.png"));
		Downarea.setBackground(new Color(0, 51, 0));
		Downarea.setBounds(120, 436, 454, 153);
		contentPane.add(Downarea);
		
		btn_back = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btn_back.setBackground(new Color(255, 153, 51));
		btn_back.setBounds(12, 520, 90, 59);
		contentPane.add(btn_back);
	
		Mainbackground = new JLabel("");
		Mainbackground.setIcon(new ImageIcon("C:\\Users\\kitri\\Desktop\\\uC790\uC0B02 \uCD5C\uC885\uC218\uC815.png"));
		Mainbackground.setBounds(0, 0, 684, 589);
		contentPane.add(Mainbackground);
		
		card.show(cardPanel, "login");
		
		exercisePage = new ExerciseRecommend();
		cardPanel.add(exercisePage, "Recommend");
		
		inbodyPage = new InbodyPage();
		cardPanel.add(inbodyPage, "inbodyChangePage");
		
		passwdPage = new PasswdPage();
		passwdPage.lbl_curpass.setText("\uD604\uC7AC \uBE44\uBC00\uBC88\uD638 :");
		cardPanel.add(passwdPage, "passwdChangePage");
		
		schedulepage = new Schedulepage();
		cardPanel.add(schedulepage, "scheduleChangePage");
		
		passSearch = new PassSearch();
		cardPanel.add(passSearch, "passwdSearchPage");
		
		joinUs = new JoinUs();
		cardPanel.add(joinUs, "joinUsPage");
		
		idSearch = new IdSearch();
		cardPanel.add(idSearch, "idSearchPage");
		
		selectMealMenuPage = new SelectMealMenuPage();
		cardPanel.add(selectMealMenuPage, "selectMealMenuPage");
		
		selectMealtime = new SelectMealtime();
		cardPanel.add(selectMealtime, "selectMealtime");
		
		informChangePage = new InformChangePage();
		cardPanel.add(informChangePage, "informChangePage");
		
		loginPage = new LoginPage();
		cardPanel.add(loginPage, "loginPage");
		
		card.show(cardPanel, "loginPage");
		
		selectGoalPage = new SelectGoalPage();
		cardPanel.add(selectGoalPage, "selectGoalPage");
		
		insertOk = new InsertOk();
		cardPanel.add(insertOk, "insertok");
		
		adminExercise = new AdminExercise();
		cardPanel.add(adminExercise, "adminexercise");
		
		adminView = new AdminPage();
		cardPanel.add(adminView, "adminpage");
		
		exerciseView = new ExerciseView();
		cardPanel.add(exerciseView, "exerciseview");
		
		userHistoryView = new UserHistoryView();
		cardPanel.add(userHistoryView, "State");
		
		dietMenuChangePage = new DietMenuChangePage();
		cardPanel.add(dietMenuChangePage, "dietmenuchangepage");
		btn_back.setVisible(false);
		startEvent();
		
		
		
	}
	
	static public void changePage(String page){
		card.show(cardPanel, page);
	}
	
	public void startEvent(){
		MainLisener mainlistener = new MainLisener(this);
		btn_Goal.addActionListener(mainlistener);
		btn_State.addActionListener(mainlistener);
		btn_Progress.addActionListener(mainlistener);
		btn_Menu.addActionListener(mainlistener);
		btn_Exercise.addActionListener(mainlistener);
		btn_Logout.addActionListener(mainlistener);
		btn_Change.addActionListener(mainlistener);
		btn_back.addActionListener(mainlistener);
		
		SelectGoalPageListener selectlistener = new SelectGoalPageListener(this);
		selectGoalPage.btn_Diet.addActionListener(selectlistener);
		selectGoalPage.btn_Muscle.addActionListener(selectlistener);
		selectMealtime.btn_Breakfast.addActionListener(selectlistener);
		selectMealtime.btn_Launch.addActionListener(selectlistener);
		selectMealtime.btn_Dinner.addActionListener(selectlistener);
		
		
		InformChangePageListener informChangeListener = 
				new InformChangePageListener(this);
		
		informChangePage.btn_Passchange.addActionListener(informChangeListener);
		informChangePage.btn_InsertInbody.addActionListener(informChangeListener);
		informChangePage.btn_Insertgoal.addActionListener(informChangeListener);
		schedulepage.btn_ScheduleEnter.addActionListener(informChangeListener);
		passwdPage.btn_PasswdEnter.addActionListener(informChangeListener);
		inbodyPage.btn_InbodyEnter.addActionListener(informChangeListener);
		informChangePage.btn_Dietmenuchange.addActionListener(informChangeListener);
		
		LoginListener loginListener = 
				new LoginListener(this);
		loginPage.btn_Login.addActionListener(loginListener);
		loginPage.btn_Id.addActionListener(loginListener);
		loginPage.btn_Join.addActionListener(loginListener);
		loginPage.btn_Pass.addActionListener(loginListener);
		joinUs.btn_JoinEnter.addActionListener(loginListener);
		idSearch.btn_IdEnter.addActionListener(loginListener);
		passSearch.btn_PasswdEnter.addActionListener(loginListener);
		insertOk.loginpageback.addActionListener(loginListener);
		
		AdminListener adminListener = new AdminListener(this);
		
		adminView.btn_Adminexer.addActionListener(adminListener);
		adminView.btn_Adminback.addActionListener(adminListener);
		adminView.btn_Adminmenu.addActionListener(adminListener);
		adminExercise.btn_ExerEnter.addActionListener(adminListener);
		
		

		InbodyInfoListener inbodyListener = new InbodyInfoListener(this);
		inbodyPage.btn_InbodyEnter.addActionListener(inbodyListener);
		
		MemHistoryListener memHistoryListener = new MemHistoryListener(this);
		userHistoryView.cboddatelist.addActionListener(memHistoryListener); 
         
		SelectMealMenuListener mealMenuListener = new SelectMealMenuListener(this);
		selectMealMenuPage.btn_FstMeal.addActionListener(mealMenuListener);
		selectMealMenuPage.btn_SndMeal.addActionListener(mealMenuListener);


		DietMenuChangePageListener userDietListener = new DietMenuChangePageListener(this);
		dietMenuChangePage.btn_DIetmenuchangeEnter.addActionListener(userDietListener);

	}
}
