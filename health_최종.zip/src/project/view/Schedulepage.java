package project.view;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;

public class Schedulepage extends JPanel {
	public JLabel lbl_finaldate;
	public JButton btn_ScheduleEnter;
	public JTextField txt_goalweight;
	public JTextField txt_muscle;
	public JLabel lbl_muscle;
	public JLabel lbl_goalweight;
	public JTextField txt_finaldate;

	/**
	 * Create the panel.
	 */
	public Schedulepage() {
		setBackground(Color.ORANGE);
		setLayout(null);
		
		lbl_finaldate = new JLabel("\uC885\uB8CC \uBAA9\uD45C\uC77C :");
		lbl_finaldate.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_finaldate.setBounds(37, 44, 102, 40);
		add(lbl_finaldate);
		
		lbl_goalweight = new JLabel("\uBAA9\uD45C \uCCB4\uC911 : ");
		lbl_goalweight.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_goalweight.setBounds(37, 100, 102, 40);
		add(lbl_goalweight);
		
		lbl_muscle = new JLabel("\uBAA9\uD45C \uADFC\uC721\uB7C9 : ");
		lbl_muscle.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_muscle.setBounds(37, 161, 102, 40);
		add(lbl_muscle);
		
		txt_finaldate = new JTextField();
		txt_finaldate.setColumns(10);
		txt_finaldate.setBounds(137, 44, 258, 40);
		add(txt_finaldate);
		
		txt_goalweight = new JTextField();
		txt_goalweight.setColumns(10);
		txt_goalweight.setBounds(137, 100, 258, 40);
		add(txt_goalweight);
		
		txt_muscle = new JTextField();
		txt_muscle.setColumns(10);
		txt_muscle.setBounds(137, 161, 258, 40);
		add(txt_muscle);
		
		btn_ScheduleEnter = new JButton("\uD655\uC778");
		btn_ScheduleEnter.setBounds(293, 224, 102, 40);
		add(btn_ScheduleEnter);

	}
}
