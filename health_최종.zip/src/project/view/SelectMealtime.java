package project.view;

import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class SelectMealtime extends JPanel {
	public JButton btn_Breakfast;
	public JButton btn_Launch;
	public JButton btn_Dinner;
	public JPanel cardPanel;

	/**
	 * Create the panel.
	 */
	public SelectMealtime() {
		setLayout(null);
		
		cardPanel = new JPanel();
		cardPanel.setBounds(12, 10, 426, 266);
		add(cardPanel);
		cardPanel.setLayout(new CardLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.ORANGE);
		cardPanel.add(panel_1, "name_295413741883583");
		panel_1.setLayout(null);
		
		btn_Breakfast = new JButton("\uC544\uCE68");
		btn_Breakfast.setBounds(128, 24, 165, 64);
		panel_1.add(btn_Breakfast);
		btn_Breakfast.setFont(new Font("�޸տ�����", Font.BOLD, 22));
		
		btn_Launch = new JButton("\uC810\uC2EC");
		btn_Launch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_Launch.setBounds(128, 108, 166, 64);
		panel_1.add(btn_Launch);
		btn_Launch.setFont(new Font("�޸տ�����", Font.BOLD, 22));
		
		btn_Dinner = new JButton("\uC800\uB141");
		btn_Dinner.setBounds(127, 189, 166, 57);
		panel_1.add(btn_Dinner);
		btn_Dinner.setFont(new Font("�޸տ�����", Font.BOLD, 22));

	}

}
