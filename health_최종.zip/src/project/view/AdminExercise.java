package project.view;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

public class AdminExercise extends JPanel {
	public JTextField txt_exername;
	public JTextField txt_cal;
	public JTextField txt_link;
	public JTextField txt_way;
	public JLabel lbl_id;
	public JLabel lbl_exername;
	public JLabel lbl_cal;
	public JLabel lbl_link;
	public JLabel lbl_way;
	public JTextField txt_id;
	public JPanel panel;
	public JButton btn_ExerEnter;

	/**
	 * Create the panel.
	 */
	public AdminExercise() {
		setLayout(null);
		
		panel = new JPanel();
		panel.setBackground(new Color(255, 140, 0));
		panel.setBounds(12, 10, 426, 309);
		add(panel);
		panel.setLayout(null);
		
		lbl_id = new JLabel("ID : ");
		lbl_id.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		lbl_id.setBounds(29, 28, 95, 28);
		panel.add(lbl_id);
		
		lbl_exername = new JLabel("\uC6B4\uB3D9\uBA85 :");
		lbl_exername.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		lbl_exername.setBounds(29, 78, 95, 28);
		panel.add(lbl_exername);
		
		lbl_cal = new JLabel("\uCE7C\uB85C\uB9AC :");
		lbl_cal.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		lbl_cal.setBounds(29, 128, 95, 28);
		panel.add(lbl_cal);
		
		lbl_link = new JLabel("\uB9C1\uD06C :");
		lbl_link.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		lbl_link.setBounds(29, 178, 95, 28);
		panel.add(lbl_link);
		
		lbl_way = new JLabel("\uC885\uB958 :");
		lbl_way.setFont(new Font("�޸տ�����", Font.BOLD, 18));
		lbl_way.setBounds(29, 228, 95, 28);
		panel.add(lbl_way);
		
		txt_id = new JTextField();
		txt_id.setColumns(10);
		txt_id.setBounds(114, 28, 274, 28);
		panel.add(txt_id);
		
		txt_exername = new JTextField();
		txt_exername.setColumns(10);
		txt_exername.setBounds(114, 78, 274, 28);
		panel.add(txt_exername);
		
		txt_cal = new JTextField();
		txt_cal.setColumns(10);
		txt_cal.setBounds(114, 128, 274, 28);
		panel.add(txt_cal);
		
		txt_link = new JTextField();
		txt_link.setColumns(10);
		txt_link.setBounds(114, 178, 274, 28);
		panel.add(txt_link);
		
		txt_way = new JTextField();
		txt_way.setColumns(10);
		txt_way.setBounds(114, 228, 274, 28);
		panel.add(txt_way);
		
		btn_ExerEnter = new JButton("\uD655\uC778");
		btn_ExerEnter.setBounds(342, 276, 72, 23);
		panel.add(btn_ExerEnter);

	}
}
