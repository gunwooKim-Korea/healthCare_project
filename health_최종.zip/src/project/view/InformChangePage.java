package project.view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class InformChangePage extends JPanel {
	public JPanel mainPage;
	public JButton btn_Passchange;
	public JButton btn_InsertInbody;
	public JLabel lblNewLabel;
	public JButton btn_Dietmenuchange;
	public JButton btn_Insertgoal;
	/**
	 * Create the panel.
	 */
	public InformChangePage() {
		setLayout(null);
		//cardPanel.setLayout(new CardLayout(0, 0));
		
		mainPage = new JPanel();
		mainPage.setBounds(0, 0, 450, 486);
		add(mainPage);
		mainPage.setLayout(null);
		
		btn_Passchange = new JButton("\uBE44\uBC00\uBC88\uD638 \uBCC0\uACBD");
		btn_Passchange.setBounds(37, 217, 122, 64);
		mainPage.add(btn_Passchange);
		btn_Passchange.setForeground(new Color(113, 54, 212));
		btn_Passchange.setBackground(new Color(255, 146, 134));
		
		btn_InsertInbody = new JButton("\uC778\uBC14\uB514 \uC785\uB825");
		btn_InsertInbody.setBounds(305, 217, 122, 64);
		mainPage.add(btn_InsertInbody);
		btn_InsertInbody.setForeground(new Color(113, 54, 212));
		btn_InsertInbody.setBackground(new Color(255, 146, 134));
		
		btn_Insertgoal = new JButton("\uBAA9\uD45C\uC77C\uC815 \uC785\uB825");
		btn_Insertgoal.setBounds(171, 217, 122, 64);
		mainPage.add(btn_Insertgoal);
		btn_Insertgoal.setForeground(new Color(113, 54, 212));
		btn_Insertgoal.setBackground(new Color(255, 146, 134));
		
		lblNewLabel = new JLabel("\uBCC0\uACBD \uC120\uD0DD");
		lblNewLabel.setBounds(177, 95, 101, 44);
		mainPage.add(lblNewLabel);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		btn_Dietmenuchange = new JButton("\uC2DD\uB2E8\uBCC0\uACBD");
		btn_Dietmenuchange.setBounds(171, 138, 122, 56);
		mainPage.add(btn_Dietmenuchange);
		startEvent();
	}
	
	public void startEvent(){
/*		InformChangePageListener listener =
				new InformChangePageListener(this);
		btn_Pass.addActionListener(listener);
		btn_Inbody.addActionListener(listener);
		btn_Sc.addActionListener(listener);
	*/	
	}
}
