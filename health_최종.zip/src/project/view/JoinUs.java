package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JoinUs extends JPanel {
	public JTextField txt_id;
	public JTextField txt_name;
	public JTextField txt_gender;
	public JTextField txt_phoneNumber;
	public JPanel panel;
	public JLabel lbl_joinus;
	public JLabel lbl_id;
	public JLabel lbl_name;
	public JLabel lbl_pass;
	public JLabel lbl_gender;
	public JLabel lbl_phoneNumber;
	public JTextField txt_email;
	public JButton btn_JoinEnter;
	public JLabel lbl_email;
	public JTextField txt_pass;

	/**
	 * Create the panel.
	 */
	public JoinUs() {
		setLayout(null);
		
		panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(-2, 0, 466, 366);
		add(panel);
		panel.setLayout(null);
		
		lbl_joinus = new JLabel("\uD68C\uC6D0\uAC00\uC785");
		lbl_joinus.setFont(new Font("����", Font.BOLD, 22));
		lbl_joinus.setBounds(180, 9, 167, 36);
		panel.add(lbl_joinus);
		
		lbl_id = new JLabel("\uC544\uC774\uB514");
		lbl_id.setFont(new Font("����", Font.BOLD, 18));
		lbl_id.setBounds(29, 52, 181, 36);
		panel.add(lbl_id);
		
		lbl_name = new JLabel("\uC774\uB984");
		lbl_name.setFont(new Font("����", Font.BOLD, 18));
		lbl_name.setBounds(29, 93, 181, 36);
		panel.add(lbl_name);
		
		lbl_pass = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lbl_pass.setFont(new Font("����", Font.BOLD, 18));
		lbl_pass.setBounds(29, 139, 181, 36);
		panel.add(lbl_pass);
		
		lbl_gender = new JLabel("\uC131\uBCC4");
		lbl_gender.setFont(new Font("����", Font.BOLD, 18));
		lbl_gender.setBounds(29, 185, 181, 36);
		panel.add(lbl_gender);
		
		lbl_phoneNumber = new JLabel("\uD578\uB4DC\uD3F0\uBC88\uD638");
		lbl_phoneNumber.setFont(new Font("����", Font.BOLD, 18));
		lbl_phoneNumber.setBounds(29, 231, 181, 36);
		panel.add(lbl_phoneNumber);
		
		lbl_email = new JLabel("\uC774\uBA54\uC77C");
		lbl_email.setFont(new Font("����", Font.BOLD, 18));
		lbl_email.setBounds(29, 277, 181, 36);
		panel.add(lbl_email);
		
		txt_id = new JTextField();
		txt_id.setBounds(156, 52, 220, 36);
		panel.add(txt_id);
		txt_id.setColumns(10);
		
		txt_name = new JTextField();
		txt_name.setColumns(10);
		txt_name.setBounds(156, 95, 220, 36);
		panel.add(txt_name);
		
		txt_pass = new JTextField();
		txt_pass.setColumns(10);
		txt_pass.setBounds(156, 139, 220, 36);
		panel.add(txt_pass);
		
		txt_gender = new JTextField();
		txt_gender.setColumns(10);
		txt_gender.setBounds(156, 185, 220, 36);
		panel.add(txt_gender);
		
		txt_phoneNumber = new JTextField();
		txt_phoneNumber.setColumns(10);
		txt_phoneNumber.setBounds(156, 231, 220, 36);
		panel.add(txt_phoneNumber);
		
		txt_email = new JTextField();
		txt_email.setColumns(10);
		txt_email.setBounds(156, 277, 220, 36);
		panel.add(txt_email);
		
		btn_JoinEnter = new JButton("\uAC00\uC785");
		btn_JoinEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_JoinEnter.setBounds(375, 320, 79, 36);
		panel.add(btn_JoinEnter);

	}
}
