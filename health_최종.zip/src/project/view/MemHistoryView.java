package project.view;

import javax.swing.JPanel;
import java.awt.CardLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.SwingConstants;

public class MemHistoryView extends JPanel {

	/**
	 * Create the panel.
	 */
	public MemHistoryView() {
		setLayout(null);
		
		JPanel toppanel = new JPanel();
		toppanel.setBackground(Color.LIGHT_GRAY);
		toppanel.setBounds(12, 10, 426, 51);
		add(toppanel);
		toppanel.setLayout(null);
		
		JLabel label = new JLabel("\uB0A0\uC9DC / \uC6B4\uB3D9\uC774\uB825 / \uC2DD\uB2E8\uC774\uB825 / \uC18C\uBAA8\uCE7C\uB85C\uB9AC ");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("�޸ո���ü", Font.BOLD, 21));
		label.setBounds(12, 10, 402, 34);
		toppanel.add(label);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(12, 71, 426, 219);
		add(panel);
		panel.setLayout(new CardLayout(0, 0));

	}
}
