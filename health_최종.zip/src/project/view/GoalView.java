package project.view;

import javax.swing.JPanel;
import java.awt.CardLayout;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JTable;

public class GoalView extends JPanel {
	public JScrollPane scroll_goalpagedatelist;
	public JPanel toppanel;
	public JTextArea ta_Goalview;

	/**
	 * Create the panel.
	 */
	public GoalView() {
		setLayout(null);
		
		toppanel = new JPanel();
		toppanel.setBackground(Color.LIGHT_GRAY);
		toppanel.setBounds(12, 10, 427, 55);
		add(toppanel);
		toppanel.setLayout(null);
		
		JLabel label = new JLabel("\uC6B4\uB3D9 \uC885\uB8CC\uC77C / \uBAA9\uD45C\uCCB4\uC911 / \uBAA9\uD45C\uADFC\uC721\uB7C9");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("�޸ո���ü", Font.BOLD, 24));
		label.setBounds(12, 10, 403, 34);
		toppanel.add(label);
		scroll_goalpagedatelist = new JScrollPane();
		scroll_goalpagedatelist.setBounds(12, 84, 427, 206);
		add(scroll_goalpagedatelist);
		
		ta_Goalview = new JTextArea();
		scroll_goalpagedatelist.setViewportView(ta_Goalview);
		

	}
}
