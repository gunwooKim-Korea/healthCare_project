package project.view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import project.dto.DietListDTO;

public class SelectGoalPage extends JPanel {
	public JTextField txt_Cal;
	public JLabel label_1;
	public JLabel label;
	public JButton btn_Diet;
	public JButton btn_Muscle;
	public JLabel lblKal;
	public SelectMealMenuPage selectMealManuPage;
	public SelectMealtime selectMealtime;
	public JPanel SelectGoal;
	public JPanel cardPanel;
	public CardLayout card;
	public static DietListDTO cur_dietlistBreak;
	public static DietListDTO cur_dietlistDinner;
	public static float kcal;
	
	/**
	 * Create the panel.
	 */
	public SelectGoalPage() {
		SelectGoalPage.cur_dietlistBreak = new DietListDTO();
		SelectGoalPage.cur_dietlistDinner = new DietListDTO();
		setLayout(null);

		cardPanel = new JPanel();
		cardPanel.setBounds(12, 10, 426, 280);
		add(cardPanel);
		card = new CardLayout(0,0);
		cardPanel.setLayout(card);
		
		SelectGoal = new JPanel();
		SelectGoal.setBackground(Color.ORANGE);
		cardPanel.add(SelectGoal, "name_295011305209925");
		SelectGoal.setLayout(null);
		
		txt_Cal = new JTextField();
		txt_Cal.setBounds(90, 79, 221, 44);
		SelectGoal.add(txt_Cal);
		txt_Cal.setHorizontalAlignment(SwingConstants.CENTER);
		txt_Cal.setColumns(10);
		
		label = new JLabel("1) \uBAA9\uD45C\uD558\uB294 \uCE7C\uB85C\uB9AC\uB97C \uC785\uB825\uD558\uC138\uC694");
		label.setBounds(78, 34, 258, 44);
		SelectGoal.add(label);
		label.setFont(new Font("����", Font.BOLD, 17));
		
		label_1 = new JLabel("2) \uC6B4\uB3D9\uBC29\uD5A5\uC744 \uC120\uD0DD\uD574\uC8FC\uC138\uC694");
		label_1.setBounds(92, 132, 223, 44);
		SelectGoal.add(label_1);
		label_1.setFont(new Font("����", Font.BOLD, 17));
		
		btn_Diet = new JButton("\uB2E4\uC774\uC5B4\uD2B8");
		btn_Diet.setBounds(89, 188, 106, 60);
		SelectGoal.add(btn_Diet);
		btn_Diet.setFont(new Font("����", Font.PLAIN, 15));
		
		btn_Muscle = new JButton("\uADFC\uC721\uB9CC\uB4E4\uAE30");
		btn_Muscle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_Muscle.setBounds(209, 189, 106, 60);
		SelectGoal.add(btn_Muscle);
		btn_Muscle.setFont(new Font("����", Font.PLAIN, 15));
		
		lblKal = new JLabel("Kcal");
		lblKal.setBounds(317, 79, 35, 45);
		SelectGoal.add(lblKal);
		lblKal.setFont(new Font("����", Font.PLAIN, 20));
       
	}

}
