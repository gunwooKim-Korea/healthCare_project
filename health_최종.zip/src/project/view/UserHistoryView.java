package project.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;

public class UserHistoryView extends JPanel {
	public JComboBox cboddatelist;
	public JTextArea text_dietDinner;
	public JTextArea text_dietBreakfast;
	public JTextArea text_kcal;

	/**
	 * Create the panel.
	 */
	public UserHistoryView() {
		setLayout(null);
		
		JPanel toppanel = new JPanel();
		toppanel.setBackground(Color.LIGHT_GRAY);
		toppanel.setBounds(12, 10, 426, 51);
		add(toppanel);
		toppanel.setLayout(null);
		
		JLabel label = new JLabel("\uB0A0\uC9DC / \uC2DD\uB2E8\uC774\uB825 / \uCE7C\uB85C\uB9AC ");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("�޸ո���ü", Font.BOLD, 21));
		label.setBounds(12, 10, 402, 34);
		toppanel.add(label);
		
		cboddatelist = new JComboBox();
		cboddatelist.setBounds(22, 71, 167, 21);
		add(cboddatelist);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 95, 450, 205);
		add(panel);
		panel.setLayout(null);
		
		text_dietBreakfast = new JTextArea();
		text_dietBreakfast.setFont(new Font("Monospaced", Font.PLAIN, 15));
		text_dietBreakfast.setBounds(86, 28, 320, 53);
		panel.add(text_dietBreakfast);
		
		text_dietDinner = new JTextArea();
		text_dietDinner.setFont(new Font("Monospaced", Font.PLAIN, 15));
		text_dietDinner.setBounds(86, 98, 319, 53);
		panel.add(text_dietDinner);
		
		text_kcal = new JTextArea();
		text_kcal.setBounds(127, 161, 179, 39);
		panel.add(text_kcal);
		
		JLabel label_1 = new JLabel("\uC544\uCE68\uC2DD\uC0AC");
		label_1.setFont(new Font("����", Font.BOLD, 12));
		label_1.setBounds(28, 30, 62, 39);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("\uC800\uB141\uC2DD\uC0AC");
		label_2.setFont(new Font("����", Font.BOLD, 12));
		label_2.setBounds(28, 102, 62, 39);
		panel.add(label_2);
		
		JLabel lblNewLabel = new JLabel("\uCD1D \uCE7C\uB85C\uB9AC");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 12));
		lblNewLabel.setBounds(43, 165, 72, 35);
		panel.add(lblNewLabel);
	

	}
}
