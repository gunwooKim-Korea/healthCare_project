package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

public class DietMenuChangePage extends JPanel {
	public JTextField txt_Breakfast;
	public JTextField txt_Dinner;
	public JTextField txt_Kcal;
	public JLabel lbl_Breakfast;
	public JLabel lbl_Lunch;
	public JLabel lbl_Kcal;
	public JButton btn_DIetmenuchangeEnter;

	/**
	 * Create the panel.
	 */
	public DietMenuChangePage() {
		setLayout(null);
		
		lbl_Breakfast = new JLabel("\uC544\uCE68 :");
		lbl_Breakfast.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_Breakfast.setBounds(57, 64, 102, 40);
		add(lbl_Breakfast);
		
		lbl_Lunch = new JLabel("\uC800\uB141 : ");
		lbl_Lunch.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_Lunch.setBounds(57, 120, 102, 40);
		add(lbl_Lunch);
		
		lbl_Kcal = new JLabel("Kcal :");
		lbl_Kcal.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_Kcal.setBounds(57, 181, 102, 40);
		add(lbl_Kcal);
		
		txt_Breakfast = new JTextField();
		txt_Breakfast.setColumns(10);
		txt_Breakfast.setBounds(105, 64, 258, 40);
		add(txt_Breakfast);
		
		txt_Dinner = new JTextField();
		txt_Dinner.setColumns(10);
		txt_Dinner.setBounds(105, 120, 258, 40);
		add(txt_Dinner);
		
		txt_Kcal = new JTextField();
		txt_Kcal.setColumns(10);
		txt_Kcal.setBounds(105, 181, 258, 40);
		add(txt_Kcal);
		
		btn_DIetmenuchangeEnter = new JButton("\uD655\uC778");
		btn_DIetmenuchangeEnter.setBounds(260, 236, 102, 40);
		add(btn_DIetmenuchangeEnter);

	}
}
