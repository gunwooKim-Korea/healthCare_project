package project.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;

import project.controller.AdminMenuNewPopListener;

public class AdminPage extends JPanel {
	public JButton btn_Adminmenu;
	public JButton btn_Adminexer;
	public JButton btn_Adminback;

	
	public AdminPage() {
		setBackground(new Color(255, 140, 0));
		setLayout(null);
		
		btn_Adminexer = new JButton("\uC6B4\uB3D9\uC785\uB825");
		btn_Adminexer.setBackground(new Color(0, 100, 0));
		btn_Adminexer.setFont(new Font("�޸տ�����", Font.BOLD, 16));
		btn_Adminexer.setBounds(35, 76, 170, 120);
		add(btn_Adminexer);
		
		btn_Adminmenu = new JButton("\uC2DD\uB2E8\uC785\uB825");
		btn_Adminmenu.setBackground(new Color(0, 100, 0));
		btn_Adminmenu.setFont(new Font("�޸տ�����", Font.BOLD, 16));
		btn_Adminmenu.setBounds(242, 76, 170, 120);
		add(btn_Adminmenu);
		
		btn_Adminback = new JButton("\uB85C\uADF8\uC778\uD398\uC774\uC9C0\uB85C");
		btn_Adminback.setBounds(12, 255, 163, 35);
		add(btn_Adminback);
		
	

	}
	
	}


