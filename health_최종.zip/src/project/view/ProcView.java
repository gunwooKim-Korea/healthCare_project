package project.view;

import javax.swing.JPanel;

import java.awt.CardLayout;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;

import java.awt.Color;

import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

import java.awt.FlowLayout;

import javax.swing.JToggleButton;

public class ProcView extends JPanel {
	public JTable table;
	public JScrollPane scrollPane;

	/**
	 * Create the panel.
	 */
	public ProcView() {
		setLayout(null);
		
		JPanel toppanel = new JPanel();
		toppanel.setBackground(Color.LIGHT_GRAY);
		toppanel.setBounds(12, 10, 426, 51);
		add(toppanel);
		toppanel.setLayout(null);
		
		JLabel label = new JLabel("\uB0A0\uC9DC / \uC6B4\uB3D9\uBA85 / \uC18C\uBAA8\uCE7C\uB85C\uB9AC / \uCCB4\uC9C0\uBC29\uB960 / \uAE30\uCD08\uB300\uC0AC\uB7C9 / \uADFC\uC721\uB7C9 / \uBAB8\uBB34\uAC8C / \uC804\uC8FC\uB300\uBE44+-% ");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("�޸ո���ü", Font.BOLD, 10));
		label.setBounds(12, 10, 402, 34);
		toppanel.add(label);
		
		table = new JTable();
		scrollPane = new JScrollPane(table);
		scrollPane.setBounds(12, 69, 426, 221);
		add(scrollPane);
	}
}
