package project.view;

import java.awt.CardLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Color;

public class LoginPage extends JPanel {
	
	public JTextField txt_ID;
	public JTextField txt_Pass;
	public JPanel panel_login;
	public JLabel ldl_iD;
	public JLabel lbl_pass;
	public JButton btn_Login;
	public JButton btn_Join;
	public JButton btn_Id;
	public JButton btn_Pass;

	/**
	 * Create the panel.
	 */
	public LoginPage() {
		setLayout(null);
		
		panel_login = new JPanel();
		panel_login.setBounds(0, 0, 452, 320);
		add(panel_login);
		panel_login.setBackground(Color.ORANGE);
		panel_login.setLayout(null);
		
		ldl_iD = new JLabel("ID");
		ldl_iD.setFont(new Font("����", Font.BOLD, 24));
		ldl_iD.setBounds(68, 101, 88, 41);
		panel_login.add(ldl_iD);
		
		lbl_pass = new JLabel("PASS");
		lbl_pass.setFont(new Font("����", Font.BOLD, 24));
		lbl_pass.setBounds(28, 138, 88, 41);
		panel_login.add(lbl_pass);
		
		txt_ID = new JTextField();
		txt_ID.setBounds(100, 101, 178, 34);
		panel_login.add(txt_ID);
		txt_ID.setColumns(10);
		
		txt_Pass = new JTextField();
		txt_Pass.setColumns(10);
		txt_Pass.setBounds(100, 138, 178, 38);
		panel_login.add(txt_Pass);
		
		btn_Login = new JButton("\uB85C\uADF8\uC778");
		btn_Login.setFont(new Font("����", Font.BOLD, 24));
		btn_Login.setBounds(282, 101, 117, 75);
		panel_login.add(btn_Login);
		
		btn_Join = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btn_Join.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		btn_Join.setBounds(62, 233, 94, 35);
		panel_login.add(btn_Join);
		
		btn_Id = new JButton("ID\uCC3E\uAE30");
		btn_Id.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		btn_Id.setBounds(197, 233, 81, 35);
		panel_login.add(btn_Id);
		
		btn_Pass = new JButton("PW\uCC3E\uAE30");
		btn_Pass.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		btn_Pass.setBounds(307, 233, 81, 35);
		panel_login.add(btn_Pass);
		
		
		startEvent();
	}
	public void startEvent(){
	/*	LoginListener listener = new LoginListener(this);
		btn_Login.addActionListener(listener);
		btn_Join.addActionListener(listener);
		btn_Id.addActionListener(listener);
		btn_Pass.addActionListener(listener);
		
	*/}
}
