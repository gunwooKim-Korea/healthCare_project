package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;

public class PassSearch extends JPanel {
	public JTextField txt_id;
	public JTextField txt_name;
	public JTextField txt_phoneNumber;
	public JButton btn_PasswdEnter;
	public JPanel panel;
	public JTextField txt_email;
	public JLabel lbl_pwsearch;
	public JLabel lbl_name;
	public JLabel lbl_id;
	public JLabel lbl_phoneNumber;
	public JLabel lbl_email;

	/**
	 * Create the panel.
	 */
	public PassSearch() {
		setLayout(null);
		
		panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 10, 450, 295);
		add(panel);
		panel.setLayout(null);
		
		lbl_pwsearch = new JLabel("PW\uCC3E\uAE30");
		lbl_pwsearch.setBounds(188, 5, 73, 24);
		lbl_pwsearch.setFont(new Font("����", Font.BOLD, 20));
		panel.add(lbl_pwsearch);
		
		lbl_name = new JLabel("\uC774\uB984");
		lbl_name.setFont(new Font("����", Font.BOLD, 20));
		lbl_name.setBounds(93, 34, 60, 51);
		panel.add(lbl_name);
		
		lbl_id = new JLabel("ID");
		lbl_id.setFont(new Font("����", Font.BOLD, 20));
		lbl_id.setBounds(103, 74, 63, 51);
		panel.add(lbl_id);
		
		lbl_phoneNumber = new JLabel("\uC804\uD654\uBC88\uD638");
		lbl_phoneNumber.setFont(new Font("����", Font.BOLD, 20));
		lbl_phoneNumber.setBounds(93, 122, 84, 51);
		panel.add(lbl_phoneNumber);
		
		lbl_email = new JLabel("\uC774\uBA54\uC77C");
		lbl_email.setFont(new Font("����", Font.BOLD, 20));
		lbl_email.setBounds(93, 169, 84, 51);
		panel.add(lbl_email);
		
		txt_name = new JTextField();
		txt_name.setColumns(10);
		txt_name.setBounds(193, 47, 155, 30);
		panel.add(txt_name);
		
		txt_id = new JTextField();
		txt_id.setBounds(193, 87, 155, 30);
		panel.add(txt_id);
		txt_id.setColumns(10);
		
		txt_phoneNumber = new JTextField();
		txt_phoneNumber.setColumns(10);
		txt_phoneNumber.setBounds(193, 130, 155, 30);
		panel.add(txt_phoneNumber);
		
		txt_email = new JTextField();
		txt_email.setColumns(10);
		txt_email.setBounds(193, 177, 155, 30);
		panel.add(txt_email);
		
		btn_PasswdEnter = new JButton("\uD655\uC778");
		btn_PasswdEnter.setBounds(239, 231, 97, 23);
		panel.add(btn_PasswdEnter);

	}
}
