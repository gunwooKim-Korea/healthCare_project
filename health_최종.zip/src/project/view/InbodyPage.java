package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;

public class InbodyPage extends JPanel {
	public JTextField txt_inbdyheight;
	public JTextField txt_inbdyweight;
	public JTextField txt_inbdymetabolism;
	public JTextField txt_inbdymuslemass;
	public JLabel lbl_inbdyheight;
	public JLabel lbl_inbdyweight;
	public JLabel lbl_inbdymetabolism;
	public JButton btn_InbodyEnter;
	public JTextField txt_inbdybodyfat;
	public JLabel lbl_muslemass;
	public JLabel lbl_inbdybodyfat;
	private JLabel lblCm;
	private JLabel lblKg;

	/**
	 * Create the panel.
	 */
	public InbodyPage() {
		setBackground(Color.ORANGE);
		setLayout(null);
		
		lbl_inbdyheight = new JLabel("     \uD0A4");
		lbl_inbdyheight.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_inbdyheight.setBounds(9, 31, 48, 28);
		add(lbl_inbdyheight);
		
		lbl_inbdyweight = new JLabel(" \uBAB8\uBB34\uAC8C");
		lbl_inbdyweight.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_inbdyweight.setBounds(9, 75, 48, 28);
		add(lbl_inbdyweight);
		
		lbl_inbdymetabolism = new JLabel("\uAE30\uCD08\uB300\uC0AC\uB7C9");
		lbl_inbdymetabolism.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_inbdymetabolism.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_inbdymetabolism.setBounds(9, 117, 71, 28);
		add(lbl_inbdymetabolism);
		
		lbl_muslemass = new JLabel("\uADFC\uC721\uB7C9");
		lbl_muslemass.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_muslemass.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_muslemass.setBounds(9, 159, 58, 28);
		add(lbl_muslemass);
		
		lbl_inbdybodyfat = new JLabel("\uCCB4\uC9C0\uBC29");
		lbl_inbdybodyfat.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_inbdybodyfat.setFont(new Font("�޸տ�����", Font.BOLD, 12));
		lbl_inbdybodyfat.setBounds(9, 210, 58, 28);
		add(lbl_inbdybodyfat);
		
		txt_inbdyheight = new JTextField();
		txt_inbdyheight.setColumns(10);
		txt_inbdyheight.setBounds(92, 31, 317, 34);
		add(txt_inbdyheight);
		
		txt_inbdyweight = new JTextField();
		txt_inbdyweight.setColumns(10);
		txt_inbdyweight.setBounds(92, 73, 317, 34);
		add(txt_inbdyweight);
		
		txt_inbdymetabolism = new JTextField();
		txt_inbdymetabolism.setColumns(10);
		txt_inbdymetabolism.setBounds(92, 117, 317, 34);
		add(txt_inbdymetabolism);
		
		txt_inbdymuslemass = new JTextField();
		txt_inbdymuslemass.setColumns(10);
		txt_inbdymuslemass.setBounds(92, 159, 317, 34);
		add(txt_inbdymuslemass);
		
		txt_inbdybodyfat = new JTextField();
		txt_inbdybodyfat.setColumns(10);
		txt_inbdybodyfat.setBounds(92, 203, 317, 34);
		add(txt_inbdybodyfat);
		
		btn_InbodyEnter = new JButton("\uD655\uC778");
		btn_InbodyEnter.setBounds(306, 247, 103, 43);
		add(btn_InbodyEnter);
		
		lblCm = new JLabel("cm");
		lblCm.setFont(new Font("����", Font.BOLD, 16));
		lblCm.setBounds(414, 31, 57, 34);
		add(lblCm);
		
		lblKg = new JLabel("kg");
		lblKg.setFont(new Font("����", Font.BOLD, 16));
		lblKg.setBounds(414, 75, 57, 34);
		add(lblKg);

	}
}
