package project.view;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import project.controller.AdminMenuNewPopListener;

public class DietDltInfo extends JFrame {

	public JPanel contentPane;
	public JPanel panel;
	public JLabel lbl_dietName;
	public JLabel lblKcal;
	public JLabel lbl_Recipe;
	public  JTextArea ta_RecipeExplain;
	public JScrollBar scrollBar;
	public JButton btn_exit;
	public JScrollPane scrollPane;

	boolean visible;
	private JTextArea textArea_1;
	private JTextArea textArea;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					AdminMenuNewPop frame = new AdminMenuNewPop();
//					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DietDltInfo(boolean visible) {
		setVisible(visible);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(5, 5, 424, 282);
		contentPane.add(panel);
		panel.setLayout(null);
		
		lbl_dietName = new JLabel("\uC74C\uC2DD\uC774\uB984");
		lbl_dietName.setFont(new Font("����", Font.BOLD, 15));
		lbl_dietName.setBounds(12, 11, 68, 21);
		panel.add(lbl_dietName);
		
		lblKcal = new JLabel("\uC601\uC591\uC815\uBCF4");
		lblKcal.setFont(new Font("����", Font.BOLD, 15));
		lblKcal.setBounds(12, 60, 68, 21);
		panel.add(lblKcal);
		
		lbl_Recipe = new JLabel("\uB808\uC2DC\uD53C \uC124\uBA85");
		lbl_Recipe.setFont(new Font("����", Font.BOLD, 15));
		lbl_Recipe.setBounds(12, 117, 97, 29);
		panel.add(lbl_Recipe);
		
		JScrollPane scroll_recipi = new JScrollPane();
		scroll_recipi.setBounds(12, 140, 400, 102);
		panel.add(scroll_recipi);
		
		btn_exit = new JButton("\uD655\uC778");
		btn_exit.setBounds(315, 245, 97, 27);
		panel.add(btn_exit);
		
		textArea_1 = new JTextArea();
		textArea_1.setBounds(99, 10, 223, 26);
		panel.add(textArea_1);
		
		textArea = new JTextArea();
		textArea.setBounds(99, 59, 223, 26);
		panel.add(textArea);
		
		startEvent();
	}

	public void startEvent() {
		
	}
}
