package project.view;

import javax.swing.JPanel;
import java.awt.Color;

public class ExerciseView extends JPanel {

	/**
	 * Create the panel.
	 */
	public ExerciseView() {
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(0, 0, 450, 300);
		add(panel);

	}

}
