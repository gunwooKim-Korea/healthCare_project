package project.view;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JButton;

public class InsertOk extends JPanel {
	public JButton loginpageback;

	/**
	 * Create the panel.
	 */
	public InsertOk() {
		setLayout(null);
		
		loginpageback = new JButton("Login Page\uB85C \uB3CC\uC544\uAC00\uAE30");
		loginpageback.setForeground(new Color(255, 165, 0));
		loginpageback.setBackground(new Color(255, 255, 255));
		loginpageback.setFont(new Font("�޸տ�����", Font.BOLD, 13));
		loginpageback.setBounds(216, 252, 222, 38);
		add(loginpageback);
		
		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0\uC73C\uB85C \uB4F1\uB85D\uB418\uC168\uC2B5\uB2C8\uB2E4.");
		lblNewLabel_1.setForeground(new Color(255, 255, 0));
		lblNewLabel_1.setFont(new Font("�޸տ�����", Font.BOLD, 26));
		lblNewLabel_1.setBounds(128, 82, 450, 300);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(InsertOk.class.getResource("/images/complete.jpg")));
		lblNewLabel.setBounds(0, 0, 450, 300);
		add(lblNewLabel);
	}
}