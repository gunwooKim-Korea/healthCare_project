package project.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JLabel;

import project.controller.DietInfoNewpopListener;
import javax.swing.JButton;

public class DietInfoNewpop extends JFrame {

	public JPanel contentPane;
	public JComboBox dietDtlList;
	public JTextArea ta_dietInfo;
	public JButton btn_exit;
	public JButton btn_choose;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					DietInfoNewpop frame = new DietInfoNewpop();
//					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DietInfoNewpop(boolean visible) {
		setVisible(visible);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 449, 468);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		dietDtlList = new JComboBox();
		dietDtlList.setBounds(76, 36, 345, 30);
		contentPane.add(dietDtlList);
		
		ta_dietInfo = new JTextArea();
		ta_dietInfo.setBounds(12, 95, 409, 285);
		contentPane.add(ta_dietInfo);
		
		JLabel lblNewLabel = new JLabel("\uC2DD\uB2E8");
		lblNewLabel.setBounds(27, 40, 37, 22);
		contentPane.add(lblNewLabel);
		
		btn_exit = new JButton("exit");
		btn_exit.setBounds(324, 396, 97, 23);
		contentPane.add(btn_exit);
		
		btn_choose = new JButton("\uC2DD\uB2E8 \uC120\uD0DD");
		btn_choose.setBounds(191, 396, 97, 23);
		contentPane.add(btn_choose);
		
		startEvent();
	}
	
	public void startEvent(){
		DietInfoNewpopListener dietInfolistener = new DietInfoNewpopListener(this);
		dietDtlList.addActionListener(dietInfolistener);
		btn_exit.addActionListener(dietInfolistener);
		btn_choose.addActionListener(dietInfolistener);
	}
}
