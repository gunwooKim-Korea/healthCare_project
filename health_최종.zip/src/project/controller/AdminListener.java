package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import project.dto.ExerciseDTO;
import project.service.MemService;
import project.service.MemServicelmpl;
import project.view.AdminMenuNewPop;
import project.view.MainView;




public class AdminListener implements ActionListener {
	MainView adminview;

	public AdminListener(MainView adminview) {
		super();
		this.adminview = adminview;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == adminview.adminView.btn_Adminexer){
			System.out.println("����");
			adminview.card.show(adminview.cardPanel,"adminexercise");
			
			
		}else if(e.getSource() == adminview.adminView.btn_Adminmenu){
			System.out.println("����");
			AdminMenuNewPop admin = new AdminMenuNewPop(true);
			
		}else if(e.getSource()==adminview.adminExercise.btn_ExerEnter){
			System.out.println("����");
			ExerciseDTO deptinfo2 =
					new ExerciseDTO(
					adminview.adminExercise.txt_id.getText(),
					adminview.adminExercise.txt_exername.getText(),
					adminview.adminExercise.txt_cal.getText(),
					adminview.adminExercise.txt_link.getText(),
					adminview.adminExercise.txt_way.getText());
			MemService service = new MemServicelmpl();
			System.out.println(deptinfo2);
			System.out.println("�����ڰ� ��Է¼���");
			int result = service.exerinsert(deptinfo2);
			MainView.changePage("adminpage");
			MainView.btn_back.setVisible(false);
		
	    }else if(e.getSource() == adminview.adminView.btn_Adminback){
			System.out.println("����");
			MainView.changePage("loginPage");
			MainView.btn_back.setVisible(false);
     }
   }
}
