package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import project.dto.UserHistoryDTO;
import project.service.MemHistoryService;
import project.service.MemHistoryServiceImpl;
import project.view.MainView;

public class MemHistoryListener implements ActionListener{

	MainView stateview;
	
	
	
	public MemHistoryListener(MainView stateview) {
		this.stateview = stateview;
	}



	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == stateview.userHistoryView.cboddatelist){

			MemHistoryService service = new MemHistoryServiceImpl();
			UserHistoryDTO history = service.getHistory(
					stateview.userHistoryView.cboddatelist.getSelectedItem().toString(), MainView.cur_user);
			
			String historydate =stateview.userHistoryView.cboddatelist.getSelectedItem().toString();
			System.out.println("���õ� ��¥ : "+historydate);
			UserHistoryDTO historyList = service.getUserHistory(MainView.cur_user.getMem_id(), historydate);
			System.out.println("MainView.cur_user.getMem_id()"+MainView.cur_user.getMem_id());
			
			if(historydate.equals(historyList.getHistorydate())
					&MainView.cur_user.getMem_id().equals(historyList.getMemId())){
				System.out.println("������ : "+historyList);
				stateview.userHistoryView.text_dietBreakfast.setText("");
				stateview.userHistoryView.text_dietDinner.setText("");
				stateview.userHistoryView.text_kcal.setText("");
				
				stateview.userHistoryView.text_dietBreakfast.append(historyList.getDietBreakfast_name());
				stateview.userHistoryView.text_dietDinner.append(historyList.getDietDinner_name());
				stateview.userHistoryView.text_kcal.append(historyList.getKcal());
				

			}

		}
	}

}
