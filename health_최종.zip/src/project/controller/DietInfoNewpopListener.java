package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import project.dto.DietDTO;
import project.dto.UserHistoryDTO;
import project.service.DietDltService;
import project.service.DietDltServiceImpl;
import project.service.UserHistoryService;
import project.service.UserHistoryServiceImpl;
import project.view.DietInfoNewpop;
import project.view.MainView;
import project.view.SelectGoalPage;

public class DietInfoNewpopListener implements ActionListener{

	DietInfoNewpop dietView;
	 static DietDTO cur_dietDTO;
	 
	public DietInfoNewpopListener(DietInfoNewpop dietView) {
		this.dietView = dietView;
	}



	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource() == dietView.dietDtlList){
			
			String name = new String(dietView.dietDtlList.getSelectedItem().toString());

			System.out.println(name);
			
			System.out.println("\nasdf");
			DietDltService service = new DietDltServiceImpl();
			DietDTO dietDTO = service.getDietDltInfo(name);
			
			dietView.ta_dietInfo.setText(dietDTO.toString());
		} else if(e.getSource() == dietView.btn_exit){
		
			dietView.dispose();
			
			
		} else if (e.getSource() == dietView.btn_choose){
			System.out.println("���ȶ�");
			
			String name = new String(dietView.dietDtlList.getSelectedItem().toString());

			System.out.println(name);
			DietDltService service = new DietDltServiceImpl();
			DietDTO dietDTO = service.getDietDltInfo(name);
			
			UserHistoryDTO tmp = new UserHistoryDTO(null,
					MainView.cur_user.getMem_id(),
					dietDTO.getDiet_name(),
					null,
					dietDTO.getDiet_kcal());
			
			System.out.println(tmp.toString());
			
			UserHistoryService service_userHistory = new UserHistoryServiceImpl();
			service_userHistory.userhistoryinsert(tmp);
		}
			
			
			
			
		}
		
	}
		
	

