package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Vector;

import project.dto.DietListDTO;
import project.service.DietListService;
import project.service.DietListServiceImpl;
import project.view.MainView;
import project.view.SelectGoalPage;

public class SelectGoalPageListener implements ActionListener {

	MainView SelectView;

	public SelectGoalPageListener() {
	}

	public SelectGoalPageListener(MainView SelectView) {
		this.SelectView = SelectView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		SelectGoalPage.kcal = Float.parseFloat(SelectView.selectGoalPage.txt_Cal.getText());
		
		if (e.getSource() == SelectView.selectGoalPage.btn_Diet) {

			MainView.card.show(MainView.cardPanel, "selectMealtime");
		} else if (e.getSource() == SelectView.selectGoalPage.btn_Muscle) {

			MainView.card.show(MainView.cardPanel, "selectMealtime");
		} else if (e.getSource() == SelectView.selectMealtime.btn_Breakfast) {
			DietListService service = new DietListServiceImpl();

			Vector<String> dietListContent = new Vector<String>();
			Vector<String> dietListId = service.getDietList();

			Vector<DietListDTO> dietListVector = new Vector<DietListDTO>();

			System.out.println("�Ĵ� ��ħ ����");
			
			for (int i = 0; i < 2; i++) {
				dietListVector.add(service
						.recomendDietList(dietListId.get(new Random()
								.nextInt(dietListId.size()))));
				dietListContent.add(dietListVector.get(i)
						.getdietlist_List());
			}

			SelectGoalPage.cur_dietlistBreak = dietListVector.get(0);
			SelectGoalPage.cur_dietlistDinner = dietListVector.get(1);

			SelectView.selectMealMenuPage.btn_FstMeal.setText(SelectGoalPage.cur_dietlistBreak.getdietlist_List());
			SelectView.selectMealMenuPage.btn_SndMeal.setText(SelectGoalPage.cur_dietlistDinner.getdietlist_List());

			MainView.card.show(MainView.cardPanel, "selectMealMenuPage");

		} else if (e.getSource() == SelectView.selectMealtime.btn_Dinner) {
			DietListService service = new DietListServiceImpl();

			Vector<String> dietListContent = new Vector<String>();
			Vector<String> dietListId = service.getDietList();
			Vector<DietListDTO> dietListVector = new Vector<DietListDTO>();

			System.out.println("�Ĵ� ���� ����");
			for (int i = 0; i < 2; i++) {
				dietListVector.add(service
						.recomendDietList(dietListId.get(new Random()
								.nextInt(dietListId.size()))));
				dietListContent.add(dietListVector.get(i)
						.getdietlist_List());
			}

			SelectGoalPage.cur_dietlistBreak = dietListVector.get(0);
			SelectGoalPage.cur_dietlistDinner = dietListVector.get(1);

			SelectView.selectMealMenuPage.btn_FstMeal.setText(SelectGoalPage.cur_dietlistBreak.getdietlist_List());
			SelectView.selectMealMenuPage.btn_SndMeal.setText(SelectGoalPage.cur_dietlistDinner.getdietlist_List());

			MainView.card.show(MainView.cardPanel, "selectMealMenuPage");
		}
	}
}