package  project.controller;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import project.dto.MemberDTO;
import project.service.MemService;
import project.service.MemServicelmpl;
import project.view.MainView;







public class LoginListener implements ActionListener{
	MainView loginView;
	
	public LoginListener(){}
	public LoginListener(MainView loginView) {
		super();
		this.loginView = loginView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// �α����ϱ� and admin(������) �α���
		if(e.getSource() == loginView.loginPage.btn_Login){
			MemService service = new MemServicelmpl();
			String id = loginView.loginPage.txt_ID.getText();
			String pass = loginView.loginPage.txt_Pass.getText();
			MemberDTO idpassInfo = service.mem_Login(id, pass);
			loginView.loginPage.txt_ID.setText("");
			loginView.loginPage.txt_Pass.setText("");
			if(idpassInfo != null && id.equals("admin")){
				MainView.changePage("adminpage");
			} else if (idpassInfo != null && !id.equals("admin")){
				MainView.changePage("main");
				MainView.btn_back.setVisible(true);
				MainView.cur_user = idpassInfo;
			} else {
				int type =JOptionPane.showConfirmDialog(loginView,
						"�α��ν���","���",
						JOptionPane.OK_CANCEL_OPTION, 
						JOptionPane.QUESTION_MESSAGE); 	
			}
	    //idã��
		}else if(e.getSource() == loginView.idSearch.btn_IdEnter){
			System.out.println("����");
			MemService service = new MemServicelmpl();
			String name = loginView.idSearch.txt_name.getText();
			String tel = loginView.idSearch.txt_phoneNumber.getText();
			String email = loginView.idSearch.txt_email.getText();
			MemberDTO nametelemailInfo = service.mem_searchID(name, tel, email);
			if(nametelemailInfo != null){
				int type =JOptionPane.showConfirmDialog(loginView,
						"���̵�ã�⼺��! \n"
						+ "����� ���̵�� : " + nametelemailInfo.getMem_id(),"���̵�ã��",
						JOptionPane.OK_CANCEL_OPTION, 
						JOptionPane.QUESTION_MESSAGE);
				if(type==JOptionPane.OK_OPTION){
					MainView.changePage("loginPage");
					loginView.idSearch.txt_name.setText("");
					loginView.idSearch.txt_email.setText("");
					loginView.idSearch.txt_phoneNumber.setText("");
				}
				
				       
			}else if(nametelemailInfo == null){
				int type =JOptionPane.showConfirmDialog(loginView,
						"���̵�ã�� ���� �ٽ��Է����ּ���!","���̵�ã��",
						JOptionPane.OK_CANCEL_OPTION, 
						JOptionPane.QUESTION_MESSAGE); 
				loginView.idSearch.txt_name.setText("");
				loginView.idSearch.txt_email.setText("");
				loginView.idSearch.txt_phoneNumber.setText("");
			}
			//�н�����ã��
		}else if(e.getSource() == loginView.passSearch.btn_PasswdEnter){
			System.out.println("����");
			MemService service = new MemServicelmpl();
			String name = loginView.passSearch.txt_name.getText();
			String id = loginView.passSearch.txt_id.getText();
			String tel = loginView.passSearch.txt_phoneNumber.getText();
			String email = loginView.passSearch.txt_email.getText();
			
			MemberDTO nameidtelemailinfo = service.mem_FindPasswd(name, id, tel, email);
			if(nameidtelemailinfo != null){
				int type =JOptionPane.showConfirmDialog(loginView,
						"�н�����ã�⼺��! \n"
						+ "����� �н������ : " + nameidtelemailinfo.getMem_passwd(),"�н�����ã��",
						JOptionPane.OK_CANCEL_OPTION, 
						JOptionPane.QUESTION_MESSAGE);
				        MainView.changePage("loginPage");
				        loginView.passSearch.txt_name.setText("");
				        loginView.passSearch.txt_id.setText("");
				        loginView.passSearch.txt_phoneNumber.setText("");
				        loginView.passSearch.txt_email.setText("");
				        
				       
			}else if(nameidtelemailinfo == null){
				int type =JOptionPane.showConfirmDialog(loginView,
						"�н�����ã�� ���� �ٽ��Է����ּ���!","�н�����ã��",
						JOptionPane.OK_CANCEL_OPTION, 
						JOptionPane.QUESTION_MESSAGE); 
				        MainView.changePage("loginPage");
				        loginView.passSearch.txt_name.setText("");
				        loginView.passSearch.txt_id.setText("");
				        loginView.passSearch.txt_phoneNumber.setText("");
				        loginView.passSearch.txt_email.setText("");
			}	
		}else if(e.getSource() == loginView.loginPage.btn_Join){
			loginView.card.show(loginView.cardPanel,"joinUsPage");
			
		}else if(e.getSource() == loginView.loginPage.btn_Id){
			loginView.card.show(loginView.cardPanel,"idSearchPage");
			
		}else if(e.getSource()==loginView.loginPage.btn_Pass){
			loginView.card.show(loginView.cardPanel,"passwdSearchPage");
			//ȸ�������ϱ� , ��й�ȣȮ�� 
		}else if(e.getSource()==loginView.joinUs.btn_JoinEnter){
			MemberDTO deptinfo =
					new MemberDTO(
					loginView.joinUs.txt_id.getText(),
					loginView.joinUs.txt_name.getText(),
					loginView.joinUs.txt_pass.getText(),
					loginView.joinUs.txt_gender.getText(),
					loginView.joinUs.txt_phoneNumber.getText(),
					loginView.joinUs.txt_email.getText());
			MemService service = new MemServicelmpl();  
			if(deptinfo == null){
				int type =JOptionPane.showConfirmDialog(loginView, "�߸��� ������ �ԷµǾ����� �ٽ� �Է����ּ���.", 
						"ȸ�����Խ���",
						JOptionPane.OK_CANCEL_OPTION, 
						JOptionPane.QUESTION_MESSAGE); 	  
				if(type==JOptionPane.OK_OPTION){
					loginView.joinUs.txt_id.setText("");  
					loginView.joinUs.txt_name.setText("");
					loginView.joinUs.txt_pass.setText("");
					loginView.joinUs.txt_gender.setText("");
					loginView.joinUs.txt_phoneNumber.setText("");
					loginView.joinUs.txt_email.setText("");
				}
		}else{
			  int result = service.mem_signUp(deptinfo);
			  MainView.card.show(MainView.cardPanel,
					  							"insertok");
			 }
			
		}else if(e.getSource() == loginView.loginPage.btn_Login){
			System.out.println("���Ǵ�");
			
		}else if(e.getSource()==loginView.idSearch.btn_IdEnter){
			
			MainView.changePage("loginPage");
			MainView.btn_back.setVisible(false);
		}else if(e.getSource()==loginView.passSearch.btn_PasswdEnter){
			MainView.changePage("loginPage");
			MainView.btn_back.setVisible(false);
		}else if(e.getSource()==loginView.insertOk.loginpageback){
			MainView.changePage("loginPage");
			MainView.btn_back.setVisible(false);
		}
	}
}