package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import project.dto.GoalDTO;
import project.service.MemService;
import project.service.MemServicelmpl;
import project.view.MainView;

public class SchedulepageListener implements ActionListener{
	
	MainView scheduleview;

	public SchedulepageListener(){}
	public SchedulepageListener(MainView scheduleview) {
		this.scheduleview = scheduleview;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == scheduleview.schedulepage.btn_ScheduleEnter){
			System.out.println("����1");
			GoalDTO goal = new GoalDTO(
					MainView.cur_user.getMem_id(),
					scheduleview.schedulepage.txt_finaldate.getText(),
					scheduleview.schedulepage.txt_goalweight.getText(),
					scheduleview.schedulepage.txt_muscle.getText());
			
			scheduleview.schedulepage.txt_finaldate.setText("");
			scheduleview.schedulepage.txt_goalweight.setText("");
			scheduleview.schedulepage.txt_muscle.setText("");
					
			System.out.println("����2");

			MemService service = new MemServicelmpl();
			System.out.println(goal);
			System.out.println("ȸ���� ��ǥ�Է¼���");
			int result = service.goalinsert(goal);
			MainView.changePage("informChangePage");
			
			
			
		}
		
		
	}
	
	
	
	


}
