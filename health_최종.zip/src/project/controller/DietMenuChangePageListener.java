package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import project.dto.UserHistoryDTO;
import project.service.UserHistoryService;
import project.service.UserHistoryServiceImpl;
import project.view.MainView;

public class DietMenuChangePageListener implements ActionListener {

	MainView mainView;

	public DietMenuChangePageListener(MainView mainView) {
		this.mainView = mainView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == mainView.dietMenuChangePage.btn_DIetmenuchangeEnter) {
			
			UserHistoryDTO tmp = new UserHistoryDTO(null,
					MainView.cur_user.getMem_id(),
					mainView.dietMenuChangePage.txt_Breakfast.getText(),
					mainView.dietMenuChangePage.txt_Dinner.getText(),
					mainView.dietMenuChangePage.txt_Kcal.getText());
			
			mainView.dietMenuChangePage.txt_Breakfast.setText("");
			mainView.dietMenuChangePage.txt_Dinner.setText("");
			mainView.dietMenuChangePage.txt_Kcal.setText("");


			
			
			UserHistoryService service = new UserHistoryServiceImpl();
			service.userhistoryinsert(tmp);
			MainView.changePage("informChangePage");
		}

	}
}