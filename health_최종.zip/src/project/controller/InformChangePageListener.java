package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import project.dto.ExerciseDTO;
import project.dto.GoalDTO;
import project.dto.MemberDTO;
import project.service.MemService;
import project.service.MemServicelmpl;
import project.view.MainView;

public class InformChangePageListener implements ActionListener {
	MainView mainView;

	public InformChangePageListener(MainView mainView) {
		super();
		this.mainView = mainView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == mainView.informChangePage.btn_Passchange) {

			mainView.card.show(mainView.cardPanel, "passwdChangePage");

		} else if (e.getSource() == mainView.informChangePage.btn_InsertInbody) {
			mainView.card.show(mainView.cardPanel, "inbodyChangePage");

		} else if (e.getSource() == mainView.informChangePage.btn_Dietmenuchange) {
			mainView.card.show(mainView.cardPanel, "dietmenuchangepage");
		    // ��ǥ���� �Է� 
		} else if (e.getSource() == mainView.informChangePage.btn_Insertgoal) {
			mainView.card.show(mainView.cardPanel, "scheduleChangePage");
            // �ιٵ� ���Է�
		} else if (e.getSource() == mainView.inbodyPage.btn_InbodyEnter) {
			mainView.card.show(mainView.cardPanel, "main");
			// �н����� ����
		} else if (e.getSource() == mainView.passwdPage.btn_PasswdEnter) {
			MemService service = new MemServicelmpl();
			
			String cur_pass = mainView.passwdPage.txt_curpass.getText();
			String ch_pass = mainView.passwdPage.txt_changepasswd.getText();
			
			if (cur_pass.equals(mainView.cur_user.getMem_passwd())) {
				MemberDTO passchangeinfo = service.mem_updatePasswd(ch_pass, 
						mainView.cur_user.getMem_id());
			}
			
        // ��ǥ�����Է�
		} else if (e.getSource() == mainView.schedulepage.btn_ScheduleEnter) {
			 
			GoalDTO goalinfo =
					new GoalDTO(MainView.cur_user.getMem_id(),
					mainView.schedulepage.txt_finaldate.getText(),
					mainView.schedulepage.txt_goalweight.getText(),
					mainView.schedulepage.txt_muscle.getText());
			MemService service = new MemServicelmpl();
			System.out.println(goalinfo);
			System.out.println("ȸ�� ��Է¼���");
			int result = service.goalinsert(goalinfo);
			MainView.changePage("informChangePage");
			
		
	}
  }
}