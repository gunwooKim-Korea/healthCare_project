package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import project.dto.ExerciseDTO;
import project.dto.InbodyinfoDTO;
import project.dto.MenuDTO;
import project.service.MemService;
import project.service.MemServicelmpl;
import project.view.InbodyPage;
import project.view.MainView;

public class InbodyInfoListener implements ActionListener {
	MainView inbodyView;

	public InbodyInfoListener(MainView inbodyView) {
		super();
		this.inbodyView = inbodyView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == inbodyView.inbodyPage.btn_InbodyEnter){
			InbodyinfoDTO inbodyinfo =
					new InbodyinfoDTO(
					inbodyView.inbodyPage.txt_inbdyheight.getText(),
					inbodyView.inbodyPage.txt_inbdyweight.getText(),
					inbodyView.inbodyPage.txt_inbdymetabolism.getText(),
					inbodyView.inbodyPage.txt_inbdymuslemass.getText(),
					inbodyView.inbodyPage.txt_inbdybodyfat.getText(),
					MainView.cur_user.getMem_id());
				
			MemService service = new MemServicelmpl();
			System.out.println(inbodyinfo);
			System.out.println("ȸ���� �ιٵ������Է¼���");
			int result = service.insertInbodyInfo(inbodyinfo);
			MainView.btn_back.setVisible(false);
			
			
			
		}
		
	}
}