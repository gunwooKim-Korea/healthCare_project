package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;

import project.dto.DietDTO;
import project.service.DietDltService;
import project.service.DietDltServiceImpl;
import project.view.DietInfoNewpop;
import project.view.MainView;
import project.view.SelectGoalPage;

public class SelectMealMenuListener implements ActionListener {
	MainView mainView;

	public SelectMealMenuListener(MainView mainView) {
		super();
		this.mainView = mainView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == mainView.selectMealMenuPage.btn_FstMeal) {
			DietInfoNewpop dietInfo = new DietInfoNewpop(true);

			DietDltService service = new DietDltServiceImpl();
			Vector<DietDTO> dietList = service
					.getDietDTO(SelectGoalPage.cur_dietlistBreak);
			Vector<String> result = new Vector<String>();

			for (int i = 0; i < dietList.size(); i++) {
				result.add(dietList.get(i).getDiet_name());
			}

			ComboBoxModel<String> model = new DefaultComboBoxModel<String>(result);

			dietInfo.dietDtlList.setModel(model);

		} else if (e.getSource() == mainView.selectMealMenuPage.btn_SndMeal) {
			DietInfoNewpop dietInfo = new DietInfoNewpop(true);

			DietDltService service = new DietDltServiceImpl();
			Vector<DietDTO> dietList = service
					.getDietDTO(SelectGoalPage.cur_dietlistDinner);
			Vector<String> result = new Vector<String>();

			for (int i = 0; i < dietList.size(); i++) {
				result.add(dietList.get(i).getDiet_name());
			}

			ComboBoxModel<String> model = new DefaultComboBoxModel<String>(result);

			dietInfo.dietDtlList.setModel(model);
		}
	}
}
