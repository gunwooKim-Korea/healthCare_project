package project.controller;

import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Vector;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;

import project.dto.ExerciseDTO;
import project.dto.GoalDTO;
import project.dto.InbodyinfoDTO;
import project.service.MemHistoryService;
import project.service.MemHistoryServiceImpl;
import project.service.MemService;
import project.service.MemServicelmpl;
import project.view.MainView;

public class MainLisener implements ActionListener {

	MainView mainView;

	public MainLisener() {
	}

	public MainLisener(MainView mainView) {
		super();
		this.mainView = mainView;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == mainView.btn_Goal) {
			mainView.card.show(mainView.cardPanel, "Goal");
			MemService service = new MemServicelmpl();
			GoalDTO goal = service.getGoalselect(MainView.cur_user
					.getMem_id());
			System.out.println(goal);
	
			// ���� ���ǥ��ȸ ��� 
			mainView.goalView.ta_Goalview.append("����� :" +
			goal.getGoal_finaldate() + "\n");
			mainView.goalView.ta_Goalview.append("��ǥü�� :" +
			goal.getGoal_weight() + "\n");
			mainView.goalView.ta_Goalview.append("��ǥ������:" + 
			goal.getGoal_muscle() + "\n");
			
			

			
		} else if (e.getSource() == mainView.btn_State) {
			mainView.card.show(mainView.cardPanel, "State");
			MemHistoryService service = new MemHistoryServiceImpl();
			Vector<String> result = service.getDateHistory(MainView.cur_user);
			ComboBoxModel<String> model = new DefaultComboBoxModel<String>(result);
			mainView.userHistoryView.cboddatelist.setModel(model);
			MainView.card.show(MainView.cardPanel, "State");;
		} else if (e.getSource() == mainView.btn_Progress) {
			mainView.card.show(mainView.cardPanel, "Prog");
			MemService service = new MemServicelmpl();
			InbodyinfoDTO inbodyinfo = service.getinbodyinfo(MainView.cur_user
					.getMem_id());
			System.out.println(inbodyinfo);

			
			 /* mainView.procView.txt_printarea.append("��¥:" +
			  inbodyinfo.getInbdy_date() + "\n");
			  mainView.procView.txt_printarea.append("Ű:" +
			  inbodyinfo.getInbdy_height() + "\n");
			  mainView.procView.txt_printarea.append("������:" +
			  inbodyinfo.getInbdy_weight() + "\n");
			  mainView.procView.txt_printarea.append("���ʴ�緮:" +
			  inbodyinfo.getInbdy_metabolism() + "\n");
			  mainView.procView.txt_printarea.append("������:" +
			  inbodyinfo.getInbdy_musclemass() + "\n");
			  mainView.procView.txt_printarea.append("ü����:" +
			  inbodyinfo.getInbdy_inbdybodyfat() + "\n");
			  mainView.procView.txt_printarea.append("ID:" +
			  MainView.cur_user.getMem_id() + "\n");
			*/

		} else if (e.getSource() == mainView.btn_Menu) {
			System.out.println("?");
			mainView.card.show(mainView.cardPanel, "selectGoalPage");
		} else if (e.getSource() == mainView.btn_Exercise) {
			mainView.card.show(mainView.cardPanel, "Recommend");
            MemService service = new MemServicelmpl();
	
			Vector<ExerciseDTO> exerciselist = service.getexerciseinfo();
			System.out.println("������=" + exerciselist.size());
			for (int i = 0; i < exerciselist.size(); i++) {
				ExerciseDTO exerciseinfo = exerciselist.get(i);
				mainView.exercisePage.textArea.append("���ȣ:"
						+ exerciseinfo.getEx_id() + "\n");
				mainView.exercisePage.textArea.append("���:"
						+ exerciseinfo.getEx_name() + "\n");
				mainView.exercisePage.textArea.append("�Ҹ�Į�θ�:"
						+ exerciseinfo.getEx_kcal() + "\n");
				mainView.exercisePage.textArea.append("��õ��ũ:"
						+ exerciseinfo.getEx_videolink() + "\n");
				mainView.exercisePage.textArea.append("�����:"
						+ exerciseinfo.getEx_type() + "\n");	
				mainView.exercisePage.textArea.append("------------------------------------------------------------------------------------------------------------------"+ "\n");
				
				try {
					Desktop.getDesktop().browse(
							new URI(exerciseinfo.getEx_videolink()));
				} catch (IOException e1) {
					
					e1.printStackTrace();
				} catch (URISyntaxException e1) {
				
					e1.printStackTrace();
				}
			}
			
		} else if (e.getSource() == mainView.btn_Logout) {
			mainView.btn_back.setVisible(false);
			mainView.card.show(mainView.cardPanel, "loginPage");
		} else if (e.getSource() == mainView.btn_Change) {
			mainView.card.show(mainView.cardPanel, "informChangePage");

		} else if (e.getSource() == mainView.btn_Logout) {
			mainView.btn_back.setVisible(false);
			mainView.card.show(mainView.cardPanel, "loginPage");
		} else if (e.getSource() == mainView.btn_Change) {
			mainView.card.show(mainView.cardPanel, "informChangePage");
		} else if (e.getSource() == mainView.btn_back) {
			mainView.card.show(mainView.cardPanel, "main");
			// JFrame�� �����ִ� btn_back �̱⶧���� "loginPage"�� �����Ͽ�����
			// ������������� �ڷΰ��⸦ �ѱ�ԵǸ� �α����������� ���ư��� ������
			// ����� ������ �α����������� �������� ���� �ʴ� �̻� �ٸ� ��ư����
			// ���� ���־�� �ذ��Ҽ� �ִ�.

		}
	}
}
