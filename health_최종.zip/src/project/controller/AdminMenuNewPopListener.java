package project.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import project.dto.DietDTO;
import project.service.MemService;
import project.service.MemServicelmpl;
import project.view.AdminMenuNewPop;
import project.view.AdminPage;

public class AdminMenuNewPopListener  implements ActionListener{
	
	AdminMenuNewPop adminPage;
	
	 public AdminMenuNewPopListener() {}

	public AdminMenuNewPopListener(AdminMenuNewPop adminPage) {
		super();
		this.adminPage = adminPage;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
			
		if(e.getSource() == adminPage.btn_AdminNewPopEnter){	
			DietDTO deptinfo3 = new DietDTO(
					adminPage.txt_dietId.getText(),
					adminPage.txt_dietName.getText(),
					adminPage.ta_Recipe.getText(),
					adminPage.txt_Kcal.getText(),
					adminPage.txt_dietlistId.getText());
					
			//MemService service = new MemServicelmpl();
			//int result = service.adminmenuinsert(deptinfo3);
			System.out.println(deptinfo3);
			System.out.println("�����ڰ� �޴��Է¼���");
			adminPage.dispose();
		}
	}
}