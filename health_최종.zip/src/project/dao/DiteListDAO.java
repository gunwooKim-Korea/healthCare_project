package project.dao;

import project.dto.DietListDTO;


public interface DiteListDAO {
	int insert(DietListDTO dietinfo);
}