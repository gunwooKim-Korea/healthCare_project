package project.dao;


import static project.fw.DBUtil.*;
import static project.fw.Query.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import project.dto.DietDTO;

public class DietDAOImpl implements DietDAO{

	@Override
	public int adminmenuInsert(DietDTO deptinfo3) {
		Connection con = null; 
		PreparedStatement stmt = null;
		int result =0;
		try{
			con = getConnect();
			stmt = con.prepareStatement(DIET_INSERT);
			stmt.setString(1,deptinfo3.getDiet_id());
			stmt.setString(2,deptinfo3.getDiet_name());
			stmt.setString(3,deptinfo3.getDiet_recipe());
			stmt.setString(4,deptinfo3.getDiet_kcal());
			stmt.setString(5, deptinfo3.getDiet_listId());
			
			result = stmt.executeUpdate();
			System.out.println(result+"�� �� ���� ����");
			
		}catch(SQLException e){
			System.out.println("�������");
			e.printStackTrace();
		}finally{
			close(null, stmt, con);
		}
		return result;
	}

	@Override
	public Vector<String> getprocdate() {
		Vector<String> deptnameList = new Vector<String>();
		Connection con  = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try{
			con= getConnect();
			stmt = con.prepareStatement("");
			rs = stmt.executeQuery();
			while(rs.next()){				
				deptnameList.add(rs.getString(1));
			}
			System.out.println("������ȸ?"+deptnameList.size());
		}catch(SQLException e){
			System.out.println("�������");
			e.printStackTrace();
		}finally{
			close(null, stmt, con);
		}
		return deptnameList;
	}

	@Override
	public Vector<DietDTO> findDietKcal(String kcal) {
		Vector<DietDTO> kcalList =new Vector<DietDTO>();
		Connection con = null; 
		PreparedStatement stmt = null;
		ResultSet rs=null;
		
		try{
			con = getConnect();
			stmt =con.prepareStatement(SELECT_DIETMENU);
			stmt.setString(1,kcal);
			rs=stmt.executeQuery();
			while(rs.next()){
				DietDTO	kcalInfo = new DietDTO(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getString(4),rs.getString(5));
				kcalList.add(kcalInfo);
			}
		}catch(SQLException e){
			System.out.println("�������");
			e.printStackTrace();
		}finally{
			close(null, stmt, con);
		}
		return kcalList;
	}

	@Override
	public Vector<DietDTO> serchDiet(String dietListId) {
		Vector<DietDTO> dietlist =new Vector<DietDTO>();
		Connection con = null; 
		PreparedStatement stmt = null;
		ResultSet rs=null;
		try{
			con = getConnect();
			stmt =con.prepareStatement(SELECT_DIETMENU);
			stmt.setString(1,dietListId);
			rs=stmt.executeQuery();
			while(rs.next()){
				DietDTO	dietInfo = new DietDTO(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getString(4),rs.getString(5));
				dietlist.add(dietInfo);
			}
		}catch(SQLException e){
			System.out.println("�������");
			e.printStackTrace();
		}finally{
			close(null, stmt, con);
		}
		return dietlist;
	}
}
