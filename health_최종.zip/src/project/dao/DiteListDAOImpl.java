package project.dao;

import static project.fw.DBUtil.close;
import static project.fw.DBUtil.getConnect;
import static project.fw.Query.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import project.dto.DietListDTO;

public class DiteListDAOImpl implements DiteListDAO{

	@Override
	public int insert(DietListDTO dietinfo) {
		Connection con = null; 
		PreparedStatement stmt = null;
		int result =0;
		try{
			con = getConnect();
			stmt = con.prepareStatement(INSERTDIETLIST_INSERT);
			stmt.setString(1,dietinfo.getdietlist_Id());
			stmt.setString(2,dietinfo.getdietlist_List());
			
			result = stmt.executeUpdate();
			System.out.println(result+"�� �� ���� ����");
			
		}catch(SQLException e){
			System.out.println("�������");
			e.printStackTrace();
		}finally{
			close(null, stmt, con);
		}
		return result;
	}
}
