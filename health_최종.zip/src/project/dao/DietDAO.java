package project.dao;

import java.util.Vector;

import project.dto.DietDTO;

public interface DietDAO {
	
	int adminmenuInsert(DietDTO deptinfo3);
	
	Vector<String> getprocdate();
	
	Vector<DietDTO> findDietKcal(String kcal);
	
	Vector<DietDTO> serchDiet(String dietListId);
}
