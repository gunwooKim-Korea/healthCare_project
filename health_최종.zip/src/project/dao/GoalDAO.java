package project.dao;


import project.dto.GoalDTO;


public interface GoalDAO {
	
	int Goalinsert(GoalDTO goalinfo);
	
	GoalDTO getGoalselect(String id);
}
