package project.dao;

import java.util.Vector;

import project.dto.ExerciseDTO;

public interface ExerciseDAO {
	int exerInsert(ExerciseDTO exerciseInfo);
	
	Vector<ExerciseDTO> getexerciseinfo();

}