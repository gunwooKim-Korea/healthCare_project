package project.dao;

import static project.fw.DBUtil.*;
import static project.fw.Query.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import project.dto.DietListDTO;

public class DietListDAOImpl implements DietListDAO {

	@Override
	public int insert(DietListDTO dietinfo) {
		Connection con = null;
		PreparedStatement stmt = null;
		int result = 0;
		try {
			con = getConnect();
			stmt = con.prepareStatement(INSERTDIETLIST_INSERT);
			stmt.setString(1, dietinfo.getdietlist_Id());
			stmt.setString(2, dietinfo.getdietlist_List());

			result = stmt.executeUpdate();
			System.out.println(result + "�� �� ���� ����");

		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return result;
	}

	@Override
	public DietListDTO recomendDietList(String id) {
		DietListDTO dietList = null;

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			con = getConnect();
			stmt = con.prepareStatement(RECOMMEND_DIETLIST);
			stmt.setString(1, id);
			rs = stmt.executeQuery();

			if (rs.next()) {
				dietList = new DietListDTO(rs.getString(1), rs.getString(2));
			}
			System.out.println("������ȸ?" + dietList);
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return dietList;
	}

	@Override
	public Vector<String> getDietListId() {
		Vector<String> dietList = new Vector<String>();

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			con = getConnect();
			stmt = con.prepareStatement(SELECT_DIETLISTID);
			rs = stmt.executeQuery();

			while (rs.next()) {
				String tmp = new String(rs.getString(1));
				dietList.add(tmp);
			}
			
			for (int i = 0; i < dietList.size(); i++) {
				System.out.println(dietList.get(i));
			}
			
			System.out.println("������ȸ?" + dietList);
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return dietList;
	}
}
