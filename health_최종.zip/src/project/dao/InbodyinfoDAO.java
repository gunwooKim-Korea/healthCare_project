package project.dao;

import java.util.Vector;

import project.dto.InbodyinfoDTO;
import project.dto.MemberDTO;

public interface InbodyinfoDAO {
   int insertInbodyInfo(InbodyinfoDTO inbodyinfo);
   
   InbodyinfoDTO getinbodyinfo(String id);
   
   Vector<String> getgoaldate();
}
