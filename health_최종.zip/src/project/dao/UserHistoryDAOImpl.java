package project.dao;

import static project.fw.DBUtil.*;

import static project.fw.Query.*;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import project.dto.MemberDTO;
import project.dto.UserHistoryDTO;

public class UserHistoryDAOImpl implements UserHistoryDAO {

	@Override
	public Vector<String> getDateHistory(MemberDTO memId) {
		Vector<String> tmpV = new Vector<String>();
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try {
			con = getConnect();

			stmt = con.prepareStatement(SELECT_MEMHISTORYDATE);
			stmt.setString(1, memId.getMem_id());
			rs = stmt.executeQuery();

			while (rs.next()) {
				String tmp = new String(rs.getString(1));
				System.out.println(tmp);
				tmpV.add(tmp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs, stmt, con);
		}
		
		return tmpV;
	}

	@Override
	public UserHistoryDTO getUserHistory(String memId,String historydate) {
		System.out.println("dao"+memId);
		UserHistoryDTO historyInfo=new UserHistoryDTO();
		Connection con = null; 
		PreparedStatement stmt = null;
		ResultSet rs=null;
		
		try{
			con = getConnect();
			stmt =con.prepareStatement(SELECT_USERHISTORY);
			stmt.setString(1,memId);
			stmt.setString(2,historydate);
			rs=stmt.executeQuery();
			while(rs.next()){
				 historyInfo=new UserHistoryDTO(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getString(4),rs.getString(5));
			}	
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		System.out.println("dao : "+historyInfo);
		return historyInfo;
		
	}

	@Override
	public int addDietMenu(UserHistoryDTO userhistory) {
		Connection con = null;
		PreparedStatement stmt = null;
		int result = 0;
		try {
			con = getConnect();
			stmt = con.prepareStatement(USERHISTORY_INSERT);
			 
			stmt.setString(1, userhistory.getMemId());
			stmt.setString(2, userhistory.getDietBreakfast_name());      
			stmt.setString(3, userhistory.getDietDinner_name());      
			stmt.setString(4, userhistory.getKcal());      
			
			result = stmt.executeUpdate();
			System.out.println(result + "�� �� ���� ����!!");
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}

		return result;
	}

	}


