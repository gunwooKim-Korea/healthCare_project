package project.dao;

import static project.fw.DBUtil.close;
import static project.fw.DBUtil.getConnect;
import static project.fw.Query.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import project.dto.GoalDTO;
import project.view.MainView;

public class GoalDAOimpl implements GoalDAO{

	@Override
	public int Goalinsert(GoalDTO goalinfo) {
		Connection con = null;
		PreparedStatement stmt = null;
		int result = 0;
		try {
			con = getConnect();
			stmt = con.prepareStatement(GOAL_INSERT);
			 
			stmt.setString(1, MainView.cur_user.getMem_id());
			stmt.setString(2, goalinfo.getGoal_finaldate());
			stmt.setString(3, goalinfo.getGoal_weight());      
			stmt.setString(4, goalinfo.getGoal_muscle());
			
	
			result = stmt.executeUpdate();
			System.out.println(result + "�� �� ���� ����!!");
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return result;
	}

	@Override
	public GoalDTO getGoalselect(String id) {
		System.out.println(id);
		GoalDTO goal =null;

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result = 0;
		

		try {
			con = getConnect();
			stmt = con.prepareStatement(GOAL_SELECT);
			stmt.setString(1, id);
			rs = stmt.executeQuery();
		
			if (rs.next()) {
				goal = new GoalDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4));
			}
			System.out.println("������ȸ?" + goal);
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return goal;
	}

}



