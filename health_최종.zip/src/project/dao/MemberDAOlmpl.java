package project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import project.dto.ExerciseDTO;
import project.dto.MenuDTO;
import project.dto.MemberDTO;
import static project.fw.DBUtil.*;
import static project.fw.Query.*;

public class MemberDAOlmpl implements MemberDAO {
	@Override
	
	public int mem_signUp(MemberDTO deptinfo) {
		Connection con = null;
		PreparedStatement stmt = null;
		int result = 0;
		try {
			con = getConnect();
			stmt = con.prepareStatement(MEMBERLIST_INSERT);
			stmt.setString(1, deptinfo.getMem_id());
			stmt.setString(2, deptinfo.getMem_name());   
			stmt.setString(3, deptinfo.getMem_passwd());    
			stmt.setString(4, deptinfo.getMem_gender());      
			stmt.setString(5, deptinfo.getMem_tel());
			stmt.setString(6, deptinfo.getMem_email());
			result = stmt.executeUpdate();
			System.out.println(result + "�� �� ���� ����!!");
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return result;
	}


	@Override
	public MemberDTO memLogin(String id, String pass) {
		MemberDTO idpassInfo = null;

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			con = getConnect();
			stmt = con.prepareStatement(IDPASS_SELECT);
			stmt.setString(1, id);
			stmt.setString(2, pass);
			rs = stmt.executeQuery();

			if (rs.next()) {
				idpassInfo = new MemberDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6),rs.getString(7));
			}
			System.out.println("������ȸ?" + idpassInfo);
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return idpassInfo;
	}

	@Override
	public MemberDTO memFindID(String name, String tel, String email) {
		MemberDTO nametelemailInfo = null;

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			con = getConnect();
			stmt = con.prepareStatement(NAMETELEMAIL_SELECT);
			stmt.setString(1, name);
			stmt.setString(2, tel);
			stmt.setString(3, email);
			rs = stmt.executeQuery();

			if (rs.next()) {
				nametelemailInfo = new MemberDTO(rs.getString(1),
						rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6),rs.getString(7));
			}
			System.out.println("������ȸ?" + nametelemailInfo);
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return nametelemailInfo;
	}

	@Override
	public MemberDTO memFindPasswd(String name, String id, String tel, String email) {
		MemberDTO nameidtelemailinfo = null;

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			con = getConnect();
			stmt = con.prepareStatement(NAMEIDTELEMAIL_SELECT);
			stmt.setString(1, name);
			stmt.setString(2, id);
			stmt.setString(3, tel);
			stmt.setString(4, email);
			rs = stmt.executeQuery();

			if (rs.next()) {
				nameidtelemailinfo = new MemberDTO(rs.getString(1),
						rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7));
			}
			System.out.println("������ȸ?" + nameidtelemailinfo);
			System.out.println(nameidtelemailinfo.getMem_passwd());
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return nameidtelemailinfo;
	}

	@Override
	public MemberDTO memUpdatePasswd(String pass, String id) {
		MemberDTO passchangeinfo = null;
		Connection con = null;
		PreparedStatement stmt = null;

		try {
			con = getConnect();
			stmt = con.prepareStatement(PASSCHANGE_UPDATE);
			stmt.setString(1, pass);
			stmt.setString(2, id);

			int result = stmt.executeUpdate();
			System.out.println(result + "�� �� ���� ����");

		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return passchangeinfo;
	}
}
