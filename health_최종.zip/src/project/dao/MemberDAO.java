package project.dao;



import java.util.Vector;

import project.dto.ExerciseDTO;
import project.dto.MenuDTO;
import project.dto.MemberDTO;


public interface MemberDAO {
	//���̺��� �μ������� insert�ϴ� �޼ҵ�
	
	int mem_signUp(MemberDTO deptinfo);
	
	MemberDTO memLogin(String id , String pass);

	MemberDTO memFindID(String name, String tel, String email);
	
	MemberDTO memFindPasswd(String name, String id, String tel , String email);
	
	MemberDTO memUpdatePasswd(String pass, String id);
}
