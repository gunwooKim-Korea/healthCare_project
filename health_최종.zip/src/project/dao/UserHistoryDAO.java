package project.dao;

import java.util.Vector;

import project.dto.MemberDTO;
import project.dto.UserHistoryDTO;

public interface UserHistoryDAO {
	
	public Vector<String> getDateHistory(MemberDTO memId);
	
	public UserHistoryDTO getUserHistory(String memId,String historydate);

	public int addDietMenu(UserHistoryDTO menuinfo);
	
}
