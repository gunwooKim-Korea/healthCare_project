package project.dao;

import java.util.Vector;

import project.dto.DietListDTO;


public interface DietListDAO {
	int insert(DietListDTO dietinfo);
	
	DietListDTO recomendDietList(String id);

	Vector<String> getDietListId();
}