package project.dao;



import static project.fw.DBUtil.*;
import static project.fw.Query.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import project.dto.InbodyinfoDTO;
import project.dto.MemberDTO;
import project.view.MainView;

public class InbodyInfoDAOImpl implements InbodyinfoDAO {

	@Override
	public int insertInbodyInfo(InbodyinfoDTO inbodyinfo) {
		Connection con = null;
		PreparedStatement stmt = null;
		int result = 0;
		try {
			con = getConnect();
			stmt = con.prepareStatement(INSERTINBODY_INSERT);
			stmt.setString(1, inbodyinfo.getInbdy_height());
			stmt.setString(2, inbodyinfo.getInbdy_weight());
			stmt.setString(3, inbodyinfo.getInbdy_metabolism());
			stmt.setString(4, inbodyinfo.getInbdy_musclemass());
			stmt.setString(5, inbodyinfo.getInbdy_inbdybodyfat());
			stmt.setString(6, MainView.cur_user.getMem_id());
						
			result = stmt.executeUpdate();
			
			System.out.println(result + "�� �� ���� ����!!");
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return result;
	}

	@Override
	public InbodyinfoDTO getinbodyinfo(String id) {
		InbodyinfoDTO inbodyinfo = null;

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			con = getConnect();
			stmt = con.prepareStatement(INSERTINBODY_SELECT);
			stmt.setString(1, id);
			rs = stmt.executeQuery();

			if (rs.next()) {
				inbodyinfo = new InbodyinfoDTO(rs.getDate(1), rs.getString(2),
						rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7));
			}
			System.out.println("������ȸ?" + inbodyinfo);
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return inbodyinfo;
	}

	@Override
	public Vector<String> getgoaldate() {
		Vector<String> deptnameList = new Vector<String>();
/*		Connection con  = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		try{
			con= getConnect();
			stmt = con.prepareStatement(GET_DEPT_NAME);
			rs = stmt.executeQuery();
			while(rs.next()){				
				deptnameList.add(rs.getString(1));
			}
			System.out.println("������ȸ?"+deptnameList.size());
		}catch(SQLException e){
			System.out.println("�������");
			e.printStackTrace();
		}finally{
			close(null, stmt, con);
		}
		*/return deptnameList;
	}
}

