package project.dao;


import static project.fw.DBUtil.*;
import static project.fw.Query.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import project.dto.ExerciseDTO;

public class ExerciseDAOImpl implements ExerciseDAO {

	@Override
	public int exerInsert(ExerciseDTO exerciseInfo) {
		Connection con = null;
		PreparedStatement stmt = null;
		int result = 0;
		try {
			con = getConnect();
			stmt = con.prepareStatement(EXERCISE_INSERT);
			stmt.setString(1, exerciseInfo.getEx_id());
			stmt.setString(2, exerciseInfo.getEx_name());
			stmt.setString(3, exerciseInfo.getEx_kcal());
			stmt.setString(4, exerciseInfo.getEx_videolink());
			stmt.setString(5, exerciseInfo.getEx_type());
			result = stmt.executeUpdate();
			System.out.println(result + "�� �� ���� ����!!");
		} catch (SQLException e) {
			System.out.println("�������");
			e.printStackTrace();
		} finally {
			close(null, stmt, con);
		}
		return result;
	}

	@Override
	public Vector<ExerciseDTO> getexerciseinfo() {
		Vector<ExerciseDTO> exerciselist = new Vector<ExerciseDTO>();
		Connection con  = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ExerciseDTO exerciseinfo =null;
		
		try{
			con= getConnect();
			stmt = con.prepareStatement(EXERCISE_SELECT);
			rs = stmt.executeQuery();
			while(rs.next()){				
				exerciseinfo = new ExerciseDTO(rs.getNString(1), rs.getNString(2),
						rs.getNString(3), rs.getNString(4), rs.getNString(5));
				exerciselist.add(exerciseinfo);
			}
			System.out.println("������ȸ?"+exerciselist.size());
		}catch(SQLException e){
			System.out.println("�������");
			e.printStackTrace();
		}finally{
			close(null, stmt, con);
		}
		return exerciselist;
	}
		
}
